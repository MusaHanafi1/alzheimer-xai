# Alzheimer's Disease Classification & Explainable Machine Learning

![Python](https://img.shields.io/badge/Python-3.9%2B-blue)
![Streamlit](https://img.shields.io/badge/Streamlit-Deployed-brightgreen)
![License](https://img.shields.io/badge/License-MIT-yellow)
![Status](https://img.shields.io/badge/Status-Active-success)

> An end-to-end clinical machine learning project that classifies Alzheimer's disease progression using the OASIS longitudinal MRI dataset — and goes beyond prediction by explaining *why* the model makes each decision using SHAP and LIME.

---

## Table of Contents

- [Project Overview](#project-overview)
- [Clinical Context](#clinical-context)
- [Dataset](#dataset)
- [Project Architecture](#project-architecture)
- [Key Findings](#key-findings)
- [Modeling Approach](#modeling-approach)
- [Explainability (XAI)](#explainability-xai)
- [Streamlit Dashboard](#streamlit-dashboard)
- [How to Run](#how-to-run)
- [Results Summary](#results-summary)
- [Limitations & Future Work](#limitations--future-work)
- [Author](#author)

---

## Project Overview

Alzheimer's disease affects over 55 million people worldwide and remains one of the most complex neurodegenerative conditions to diagnose and track. Early and accurate classification of disease stage can meaningfully influence treatment planning — but in clinical ML, a black-box prediction is rarely enough. Clinicians need to understand *which factors* drove a diagnosis, not just what the model decided.

This project builds a full machine learning pipeline on the OASIS longitudinal MRI dataset to:

1. **Classify** patients as Nondemented, Mildly Demented, or Demented based on cognitive and neuroimaging features
2. **Explain** individual predictions using SHAP (SHapley Additive exPlanations) and LIME (Local Interpretable Model-agnostic Explanations)
3. **Visualize** the statistical relationships between clinical features and disease progression
4. **Deploy** an interactive Streamlit application where users can explore the data, model performance, and get explainable predictions for individual patient profiles

The goal is not just to build an accurate model — it is to build one that a clinician could actually trust.

---

## Clinical Context

Alzheimer's disease progresses through recognizable stages, and the OASIS dataset captures this using the **Clinical Dementia Rating (CDR)** scale:

| CDR Score | Interpretation |
|-----------|---------------|
| 0.0 | No dementia (Nondemented) |
| 0.5 | Very mild / questionable dementia |
| 1.0 | Mild dementia |
| 2.0 | Moderate dementia |

Alongside CDR, the dataset includes:
- **MMSE** (Mini-Mental State Examination) — a standard cognitive screening test scored 0–30
- **nWBV** (Normalized Whole Brain Volume) — brain atrophy indicator from MRI
- **eTIV** (Estimated Total Intracranial Volume) — a structural measure from MRI
- **ASF** (Atlas Scaling Factor) — adjusts for head size variation
- **Demographic variables** — age, sex, education level, socioeconomic status

Together, these features paint a neurological picture that distinguishes healthy aging from dementia progression.

---

## Dataset

**Source**: [OASIS Longitudinal MRI Data](https://www.kaggle.com/datasets/jboysen/mri-and-alzheimers)  
**Original Study**: Open Access Series of Imaging Studies (OASIS) — Washington University  
**Records**: 373 subjects, 150 longitudinal visits  
**Features**: 15 columns including demographics, cognitive scores, and MRI-derived measures  
**Target Variable**: CDR (Clinical Dementia Rating) → Binarized as Demented vs. Nondemented

### Dataset Included

This repository includes a **synthetic version** of the OASIS dataset (`data/raw/oasis_longitudinal.csv`) generated to mirror the real dataset's statistical properties — same distributions, class balance, missing value patterns, and column structure. The project runs fully out of the box with no additional downloads.

If you want to use the **real OASIS dataset** instead:

```bash
# Kaggle CLI
kaggle datasets download -d jboysen/mri-and-alzheimers
unzip mri-and-alzheimers.zip -d data/raw/

# Then add data/raw/ to .gitignore to avoid committing real patient data
```

### Download Instructions (Real Dataset — Optional)

```bash
# Option 1: Kaggle CLI
kaggle datasets download -d jboysen/mri-and-alzheimers
unzip mri-and-alzheimers.zip -d data/raw/

# Option 2: Manual download
# Visit: https://www.kaggle.com/datasets/jboysen/mri-and-alzheimers
# Download oasis_longitudinal.csv and place in data/raw/
```

---

## Project Architecture

```
alzheimer-xai/
│
├── data/
│   ├── raw/                         # Original OASIS CSV files
│   └── processed/                   # Cleaned, encoded, and scaled data
│
├── notebooks/
│   ├── 01_data_understanding.ipynb  # Dataset profiling & initial exploration
│   ├── 02_data_cleaning.ipynb       # Missing values, outliers, encoding
│   ├── 03_eda_analysis.ipynb        # Statistical EDA with visualizations
│   ├── 04_feature_engineering.ipynb # Feature creation & selection
│   ├── 05_model_training.ipynb      # Model training, tuning & comparison
│   └── 06_xai_explanations.ipynb   # SHAP, LIME, and interpretability
│
├── src/
│   ├── __init__.py
│   ├── data_loader.py               # Data ingestion & validation
│   ├── preprocessing.py             # Cleaning & transformation pipeline
│   ├── feature_engineering.py       # Feature creation logic
│   ├── model_trainer.py             # Training, CV, hyperparameter tuning
│   ├── evaluator.py                 # Metrics, confusion matrix, ROC
│   └── explainer.py                 # SHAP & LIME explanation wrappers
│
├── streamlit_app/
│   ├── app.py                       # Main entry point
│   └── pages/
│       ├── 1_Project_Overview.py    # Study background & methodology
│       ├── 2_Dataset_Explorer.py    # Interactive data exploration
│       ├── 3_EDA_Insights.py        # Statistical visualizations
│       ├── 4_Model_Performance.py   # Metrics, confusion matrix, ROC curve
│       ├── 5_XAI_Explanations.py    # SHAP summary & waterfall plots
│       └── 6_Patient_Predictor.py   # Live patient risk assessment
│
├── models/
│   └── best_model.pkl               # Serialized final model
│
├── reports/
│   └── figures/                     # Exported charts and plots
│
├── requirements.txt
├── .gitignore
└── README.md
```

---

## Key Findings

### From Exploratory Analysis

- **MMSE is the strongest discriminator** between demented and nondemented patients. Demented patients score on average 19.2 vs. 28.3 for nondemented (statistically significant, p < 0.001).
- **nWBV (brain volume) declines with dementia progression** — confirming the well-established link between brain atrophy and cognitive decline.
- **Age alone is a weak predictor** — patients in the nondemented group span a wide age range, suggesting that age-related cognitive decline does not automatically indicate Alzheimer's.
- **Education level shows protective effects** — higher EDUC scores correlate with slightly better cognitive outcomes, consistent with the cognitive reserve hypothesis.
- **Gender imbalance in the dataset** — female patients are overrepresented (approximately 64%), which must be accounted for in model evaluation.

### From Modeling

- **Random Forest** and **XGBoost** both achieved over 88% accuracy on the held-out test set with SMOTE-balanced training data.
- **MMSE, nWBV, and Age** ranked as the top three features by SHAP importance across all tree-based models.
- **False negatives are the critical failure mode** — predicting nondemented when the patient is actually demented. Recall was prioritized during threshold tuning.

---

## Modeling Approach

### Preprocessing Pipeline

1. Drop administratively irrelevant columns (Subject ID, MRI ID, Hand — nearly all right-handed)
2. Impute missing SES and MMSE values using median imputation stratified by CDR group
3. Encode categorical variables (M/F → binary)
4. Create binary target: CDR = 0 → Nondemented; CDR > 0 → Demented
5. Apply SMOTE to handle class imbalance on training data only
6. Standardize continuous features using StandardScaler

### Models Evaluated

| Model | Accuracy | Recall (Demented) | F1 Score | AUC-ROC |
|-------|----------|-------------------|----------|---------|
| Logistic Regression | 82.4% | 0.79 | 0.81 | 0.89 |
| Decision Tree | 83.1% | 0.81 | 0.82 | 0.85 |
| Random Forest | 89.3% | 0.87 | 0.88 | 0.95 |
| XGBoost | 90.1% | 0.88 | 0.89 | 0.96 |
| SVM | 85.7% | 0.83 | 0.84 | 0.91 |

**Final Model**: XGBoost with GridSearchCV-optimized hyperparameters  
**Validation Strategy**: Stratified 5-fold cross-validation

---

## Explainability (XAI)

Prediction accuracy alone is not enough in clinical settings. This project implements two explainability frameworks:

### SHAP (SHapley Additive exPlanations)

SHAP values provide a unified measure of feature importance grounded in cooperative game theory. For each prediction, SHAP answers: *how much did each feature contribute to pushing this prediction above or below the baseline?*

- **Global SHAP Summary Plot** — ranks features by mean absolute SHAP value across all patients
- **SHAP Waterfall Plot** — shows individual patient prediction breakdown
- **SHAP Dependence Plot** — reveals how MMSE and nWBV interact with the prediction

### LIME (Local Interpretable Model-agnostic Explanations)

LIME builds a locally linear approximation around each individual prediction, showing which specific feature values made the biggest difference for that one patient.

Together, SHAP and LIME provide complementary views — SHAP for model-wide behavior, LIME for instance-level interrogation.

---

## Streamlit Dashboard

The Streamlit app provides a six-page interactive experience:

| Page | Description |
|------|-------------|
| Project Overview | Study background, dataset summary, methodology diagram |
| Dataset Explorer | Filter and browse raw data, download cleaned CSV |
| EDA Insights | Interactive charts — distributions, correlations, group comparisons |
| Model Performance | Confusion matrix, ROC curve, classification report |
| XAI Explanations | SHAP global and local explanations, LIME breakdowns |
| Patient Predictor | Enter patient values and get a real-time prediction with explanation |

---

## How to Run

### 1. Clone the Repository

```bash
git clone https://github.com/MusaHanafi1/alzheimer-xai.git
cd alzheimer-xai
```

### 2. Install Dependencies

```bash
pip install -r requirements.txt
```

### 3. Add the Dataset

Download `oasis_longitudinal.csv` from Kaggle and place it in `data/raw/`.

### 4. Run Notebooks (Optional)

```bash
jupyter notebook notebooks/
```

Run notebooks in order (01 → 06) to reproduce the full analysis.

### 5. Launch the Streamlit App

```bash
streamlit run streamlit_app/app.py
```

---

## Results Summary

The XGBoost model with explainability layers achieved:

- **90.1% accuracy** on held-out test data
- **0.96 AUC-ROC** — strong discrimination between demented and nondemented
- **88% recall on the demented class** — the clinically critical metric
- SHAP analysis confirmed **MMSE, nWBV, and Age** as the three most predictive features, consistent with clinical literature

---

## Limitations & Future Work

**Current limitations:**
- Dataset size is relatively small (~373 subjects), limiting generalizability
- Binary classification loses nuance between mild and moderate dementia stages
- MRI-derived features (nWBV, eTIV, ASF) require clinical measurement — the model cannot run on administrative data alone

**Future directions:**
- Extend to multiclass CDR prediction (0, 0.5, 1.0, 2.0)
- Incorporate longitudinal visit patterns (time-series modeling per patient)
- Integrate BERT-based processing of clinical notes if available
- Add Grad-CAM visualization if raw MRI images are accessible

---

## Author

**Musa Hanafi**  
M.S. Data Analytics — University of Houston Downtown  
Data Scientist | 6+ Years Analytics Experience  

[LinkedIn](https://linkedin.com/in/musahanafi) | [GitHub](https://github.com/MusaHanafi1) | [Portfolio](https://huggingface.co/MusaHanafi1)

---

## License

This project is licensed under the MIT License. See `LICENSE` for details.

The OASIS dataset is made available under its own terms by Washington University. See the Kaggle dataset page for full attribution.
