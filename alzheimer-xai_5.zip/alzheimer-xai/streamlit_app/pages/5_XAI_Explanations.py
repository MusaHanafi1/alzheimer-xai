"""
5_XAI_Explanations.py — SHAP global and local explanations.
"""

import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import shap
import sys
import os
import warnings
warnings.filterwarnings('ignore')

sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))
from src.data_loader import load_oasis
from src.preprocessing import clean_dataset, split_features_target, scale_features
from src.feature_engineering import add_clinical_features
from src.model_trainer import train_test_split_data, apply_smote, load_model
from src.explainer import (
    get_shap_explainer, compute_shap_values,
    plot_shap_bar, plot_shap_dependence,
    get_lime_explainer, explain_with_lime, plot_lime_explanation
)

st.set_page_config(page_title="XAI Explanations", page_icon="🔍", layout="wide")
st.title("🔍 Explainability — SHAP & LIME")
st.markdown("""
A prediction alone is not enough for clinical use. This page shows **why** the model
classifies each patient the way it does — globally across the entire dataset, and for individual patients.
""")

DATA_PATH = os.path.join(os.path.dirname(__file__), '..', '..', 'data', 'raw', 'oasis_longitudinal.csv')
MODEL_PATH = os.path.join(os.path.dirname(__file__), '..', '..', 'models', 'best_model.pkl')

@st.cache_data
def load_xai_data():
    try:
        df_raw = load_oasis(DATA_PATH)
        df_clean = clean_dataset(df_raw)
        df_eng = add_clinical_features(df_clean)
        X, y = split_features_target(df_eng)
        X_train, X_test, y_train, y_test = train_test_split_data(X, y)
        X_train_sc, X_test_sc, _ = scale_features(X_train, X_test)
        X_train_df = pd.DataFrame(X_train_sc, columns=X_train.columns)
        X_test_df  = pd.DataFrame(X_test_sc, columns=X_test.columns)
        X_train_res, y_train_res = apply_smote(X_train_df, y_train.reset_index(drop=True))
        X_train_res = pd.DataFrame(X_train_res, columns=X_train.columns)
        return X_test_df, y_test.reset_index(drop=True), X_train_df, X_train_res
    except Exception:
        return None, None, None, None

if not os.path.exists(MODEL_PATH):
    st.warning("Model not found. Run Notebook 05 first.")
    st.stop()

X_test, y_test, X_train_df, X_train_res = load_xai_data()
if X_test is None:
    st.error("Data not found.")
    st.stop()

model = load_model(MODEL_PATH)

tab1, tab2, tab3 = st.tabs(["SHAP Global", "SHAP Individual Patient", "LIME Explanation"])

# ── Tab 1: SHAP Global ─────────────────────────────────────────────
with tab1:
    st.subheader("Global Feature Importance — SHAP")
    st.markdown("""
    **What is SHAP?** SHAP (SHapley Additive exPlanations) uses game theory to assign each
    feature a contribution value for every prediction. The global view aggregates these across
    all patients to show which features matter most to the model overall.
    """)

    with st.spinner("Computing SHAP values..."):
        explainer   = get_shap_explainer(model, X_train_df)
        shap_values = compute_shap_values(explainer, X_test)

    col1, col2 = st.columns(2)

    with col1:
        st.markdown("**Mean |SHAP Value| — Feature Importance Bar Chart**")
        fig = plot_shap_bar(shap_values, X_test)
        st.pyplot(fig)
        plt.close()
        st.caption("Higher bar = greater average impact on predictions across all patients.")

    with col2:
        st.markdown("**SHAP Beeswarm Summary**")
        fig2, ax2 = plt.subplots(figsize=(9, 5))
        shap.summary_plot(shap_values, X_test, show=False, plot_type='dot')
        plt.title("SHAP Beeswarm — Direction & Magnitude of Feature Impact", fontsize=11, pad=10)
        plt.tight_layout()
        st.pyplot(fig2)
        plt.close()
        st.caption("Red = high feature value, Blue = low. Rightward = pushes toward Demented prediction.")

    st.markdown("---")
    st.subheader("SHAP Dependence Plot")
    st.markdown("How does a feature's SHAP value change across its range? Hover over a different interaction feature to reveal conditional effects.")

    dep_feature = st.selectbox("Primary feature:", list(X_test.columns), index=list(X_test.columns).index('MMSE') if 'MMSE' in X_test.columns else 0)
    interaction = st.selectbox("Interaction feature (color):", list(X_test.columns), index=list(X_test.columns).index('nWBV') if 'nWBV' in X_test.columns else 1)

    fig3 = plot_shap_dependence(shap_values, X_test, dep_feature, interaction)
    st.pyplot(fig3)
    plt.close()

# ── Tab 2: SHAP Individual ─────────────────────────────────────────
with tab2:
    st.subheader("Individual Patient — SHAP Waterfall")
    st.markdown("""
    A waterfall plot shows how each feature pushed this specific patient's prediction
    above or below the model's baseline expectation. This is what you would show a clinician
    explaining *why* the model flagged this patient.
    """)

    y_pred = model.predict(X_test)
    y_test_arr = y_test.values

    true_positives  = np.where((y_test_arr == 1) & (y_pred == 1))[0]
    true_negatives  = np.where((y_test_arr == 0) & (y_pred == 0))[0]
    false_negatives = np.where((y_test_arr == 1) & (y_pred == 0))[0]

    patient_type = st.radio(
        "Select patient type to examine:",
        ["True Positive (Correctly Demented)", "True Negative (Correctly Nondemented)", "False Negative (Missed Dementia)"],
        horizontal=True
    )

    if "True Positive" in patient_type and len(true_positives) > 0:
        idx_pool = true_positives
        label = "Correctly classified as Demented"
    elif "True Negative" in patient_type and len(true_negatives) > 0:
        idx_pool = true_negatives
        label = "Correctly classified as Nondemented"
    elif "False Negative" in patient_type and len(false_negatives) > 0:
        idx_pool = false_negatives
        label = "Missed — predicted Nondemented but actually Demented"
    else:
        idx_pool = np.arange(len(X_test))
        label = "Random patient"

    patient_idx = st.slider("Select patient index:", 0, len(idx_pool) - 1, 0)
    actual_idx = idx_pool[patient_idx]

    st.info(f"Patient #{actual_idx} | {label}")

    col_a, col_b = st.columns([1, 2])
    with col_a:
        st.markdown("**Patient Profile:**")
        patient_data = X_test.iloc[actual_idx].round(4)
        proba = model.predict_proba(X_test.iloc[[actual_idx]])[0]
        st.dataframe(pd.DataFrame({'Feature': patient_data.index, 'Value': patient_data.values}),
                     use_container_width=True, height=300)
        st.metric("P(Demented)", f"{proba[1]*100:.1f}%")
        st.metric("P(Nondemented)", f"{proba[0]*100:.1f}%")

    with col_b:
        with st.spinner("Computing SHAP waterfall..."):
            shap_explanation = explainer(X_test)
        fig_wf, ax_wf = plt.subplots(figsize=(9, 5))
        shap.plots.waterfall(shap_explanation[actual_idx], max_display=10, show=False)
        plt.title(f"SHAP Waterfall — Patient #{actual_idx}", fontsize=11)
        plt.tight_layout()
        st.pyplot(fig_wf)
        plt.close()

# ── Tab 3: LIME ────────────────────────────────────────────────────
with tab3:
    st.subheader("LIME — Local Interpretable Explanation")
    st.markdown("""
    **What is LIME?** LIME (Local Interpretable Model-agnostic Explanations) builds a simple
    linear model around each individual prediction. It shows which specific feature values
    in this patient drove the classification — in plain, linear terms a clinician can follow.

    LIME and SHAP often agree on top features, but LIME is better for generating
    **plain-language narratives** for non-technical audiences.
    """)

    lime_idx = st.slider("Patient index (test set):", 0, len(X_test) - 1, 0, key="lime_slider")

    with st.spinner("Computing LIME explanation..."):
        lime_explainer = get_lime_explainer(X_train_df)
        lime_weights   = explain_with_lime(lime_explainer, model, X_test, lime_idx)

    col1, col2 = st.columns(2)

    with col1:
        fig_lime = plot_lime_explanation(lime_weights, lime_idx)
        st.pyplot(fig_lime)
        plt.close()
        st.caption("Green bars push toward Demented, red bars push toward Nondemented.")

    with col2:
        proba_lime = model.predict_proba(X_test.iloc[[lime_idx]])[0]
        actual_label = "Demented" if y_test.values[lime_idx] == 1 else "Nondemented"
        pred_label   = "Demented" if model.predict(X_test.iloc[[lime_idx]])[0] == 1 else "Nondemented"

        st.metric("Actual Diagnosis", actual_label)
        st.metric("Model Prediction", pred_label)
        st.metric("P(Demented)", f"{proba_lime[1]*100:.1f}%")

        st.markdown("**LIME Feature Weights (sorted by impact):**")
        lime_df = pd.DataFrame(
            sorted(lime_weights.items(), key=lambda x: abs(x[1]), reverse=True),
            columns=['Feature Condition', 'LIME Weight']
        )
        lime_df['LIME Weight'] = lime_df['LIME Weight'].round(4)
        lime_df['Direction'] = lime_df['LIME Weight'].apply(
            lambda x: '↑ Demented' if x > 0 else '↓ Nondemented'
        )
        st.dataframe(lime_df, use_container_width=True)

    st.markdown("---")
    st.markdown("""
    **SHAP vs LIME — When to Use Which**

    | Aspect | SHAP | LIME |
    |--------|------|------|
    | Scope | Global + local | Local only |
    | Consistency | Guaranteed (game theory axioms) | Approximate |
    | Speed | Fast (TreeExplainer) | Slower (perturbation-based) |
    | Best audience | Data scientists, clinical leads | Clinicians, patients |
    | Output | Shapley values | Linear weights |
    """)
