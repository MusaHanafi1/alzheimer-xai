"""
2_Dataset_Explorer.py — Interactive dataset browsing and filtering.
"""

import streamlit as st
import pandas as pd
import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))
from src.data_loader import load_oasis, get_feature_metadata

st.set_page_config(page_title="Dataset Explorer", page_icon="📊", layout="wide")
st.title("📊 Dataset Explorer")
st.markdown("Browse, filter, and understand the OASIS longitudinal clinical dataset.")

DATA_PATH = os.path.join(os.path.dirname(__file__), '..', '..', 'data', 'raw', 'oasis_longitudinal.csv')

@st.cache_data
def load_data():
    try:
        return load_oasis(DATA_PATH)
    except FileNotFoundError:
        return None

df = load_data()

if df is None:
    st.error("Dataset not found. Please download `oasis_longitudinal.csv` from Kaggle and place it in `data/raw/`.")
    st.markdown("[Download from Kaggle →](https://www.kaggle.com/datasets/jboysen/mri-and-alzheimers)")
    st.stop()

# Sidebar filters
st.sidebar.header("Filter Data")
groups = st.sidebar.multiselect("Diagnostic Group", df['Group'].unique().tolist(),
                                  default=df['Group'].unique().tolist())
age_range = st.sidebar.slider("Age Range", int(df['Age'].min()), int(df['Age'].max()),
                               (int(df['Age'].min()), int(df['Age'].max())))
gender = st.sidebar.multiselect("Gender", ['M', 'F'], default=['M', 'F'])

df_filtered = df[
    (df['Group'].isin(groups)) &
    (df['Age'] >= age_range[0]) &
    (df['Age'] <= age_range[1]) &
    (df['M/F'].isin(gender))
]

# Summary cards
col1, col2, col3, col4 = st.columns(4)
col1.metric("Total Records", len(df_filtered))
col2.metric("Unique Subjects", df_filtered['Subject ID'].nunique() if 'Subject ID' in df_filtered.columns else "N/A")
col3.metric("Demented (%)", f"{(df_filtered['Group'] == 'Demented').mean()*100:.1f}%")
col4.metric("Avg MMSE", f"{df_filtered['MMSE'].mean():.1f}")

st.markdown("---")

# Data table
st.subheader("Filtered Dataset")
st.dataframe(df_filtered.reset_index(drop=True), use_container_width=True, height=400)

# Download button
csv = df_filtered.to_csv(index=False).encode('utf-8')
st.download_button("Download Filtered CSV", csv, "oasis_filtered.csv", "text/csv")

st.markdown("---")

# Feature descriptions
st.subheader("Feature Descriptions")
metadata = get_feature_metadata()
desc_df = pd.DataFrame(list(metadata.items()), columns=["Feature", "Description"])
st.table(desc_df)

# Missing value summary
st.subheader("Missing Value Summary")
missing = df_filtered.isnull().sum()
missing_pct = (missing / len(df_filtered) * 100).round(2)
missing_table = pd.DataFrame({'Missing Count': missing, 'Missing %': missing_pct})
missing_table = missing_table[missing_table['Missing Count'] > 0]
if len(missing_table) > 0:
    st.dataframe(missing_table, use_container_width=True)
else:
    st.success("No missing values in the filtered selection.")
