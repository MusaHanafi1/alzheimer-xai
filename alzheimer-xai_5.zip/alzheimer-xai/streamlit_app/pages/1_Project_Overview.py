"""
1_Project_Overview.py — Study background, methodology, and dataset overview.
"""

import streamlit as st

st.set_page_config(page_title="Project Overview", page_icon="🧠", layout="wide")

st.title("🧠 Project Overview")
st.markdown("*Alzheimer's Disease Classification & Explainable ML — OASIS Longitudinal Dataset*")
st.markdown("---")

col1, col2 = st.columns([2, 1])

with col1:
    st.markdown("""
    ### Why This Project Exists

    Alzheimer's disease affects over **55 million people worldwide** and remains one of the
    most complex neurodegenerative conditions to diagnose and track. Early classification of
    disease stage directly influences treatment planning — but in clinical machine learning,
    a black-box prediction is rarely enough.

    Clinicians need to understand *which factors* drove a diagnosis, not just what the model
    decided. This project addresses both problems:

    - **Classifies** patients as Nondemented or Demented based on cognitive and MRI features
    - **Explains** individual predictions using SHAP and LIME
    - **Deploys** the full pipeline as an interactive clinical decision-support tool

    ---

    ### The Dataset

    The **OASIS (Open Access Series of Imaging Studies)** longitudinal dataset was collected
    at Washington University and includes 373 subjects across 150 clinical visits.

    | Variable | Description |
    |----------|-------------|
    | MMSE | Mini-Mental State Examination (0–30, higher = better cognition) |
    | nWBV | Normalized Whole Brain Volume — MRI-derived atrophy measure |
    | eTIV | Estimated Total Intracranial Volume |
    | ASF | Atlas Scaling Factor (head-size correction) |
    | Age | Patient age in years |
    | EDUC | Years of formal education |
    | SES | Socioeconomic status (1 = highest, 5 = lowest) |
    | CDR | Clinical Dementia Rating — our target variable |

    ---

    ### Methodology Pipeline

    1. **Data Understanding** — OASIS structure, longitudinal design, missing value profiling
    2. **Data Cleaning** — Deduplication by latest visit, imputation, CDR binarization
    3. **EDA & Statistics** — Mann-Whitney U tests, effect sizes, correlation analysis
    4. **Feature Engineering** — MMSE-Age ratio, brain atrophy score, cognitive reserve proxy
    5. **Model Training** — 5-fold CV across 5 models, SMOTE balancing, XGBoost tuning
    6. **Explainability** — SHAP global + local, LIME instance-level explanations

    ---

    ### Clinical Context

    The CDR scale measures dementia severity:

    | CDR | Interpretation |
    |-----|---------------|
    | 0.0 | No dementia |
    | 0.5 | Very mild / questionable |
    | 1.0 | Mild dementia |
    | 2.0 | Moderate dementia |

    For this binary classification task: **CDR = 0 → Nondemented, CDR > 0 → Demented**.
    """)

with col2:
    st.markdown("### Model Results")
    st.metric("Final Model", "XGBoost (Tuned)")
    st.metric("Test Accuracy", "90.1%")
    st.metric("AUC-ROC", "0.961")
    st.metric("Recall (Demented)", "88.0%")
    st.metric("F1 Score", "89.0%")

    st.markdown("---")
    st.markdown("### Top Predictive Features")
    st.markdown("""
    1. 🧪 **MMSE Score** — largest effect size
    2. 🧠 **nWBV** — brain atrophy from MRI
    3. 📅 **Age** — moderate predictor
    4. 🎓 **Education** — cognitive reserve
    5. 💰 **SES** — socioeconomic factor
    """)

    st.markdown("---")
    st.markdown("### Links")
    st.markdown("""
    - [OASIS Dataset (Kaggle)](https://www.kaggle.com/datasets/jboysen/mri-and-alzheimers)
    - [GitHub Repository](https://github.com/MusaHanafi1/alzheimer-xai)
    - [Original OASIS Study](https://sites.wustl.edu/oasisbrains/)
    """)

st.markdown("---")
st.markdown("""
### Key Findings at a Glance

> **MMSE is the single strongest predictor.** Demented patients score on average 9 points
> lower than nondemented patients — a statistically significant difference (p < 0.001, large effect size).

> **Brain volume (nWBV) confirms the atrophy link.** Lower normalized whole brain volume
> correlates strongly with dementia, consistent with decades of neuroimaging research.

> **Age alone is a weak predictor.** Both groups span a wide age range, confirming that
> aging does not automatically indicate Alzheimer's disease.

> **Education shows protective effects.** Higher EDUC correlates with better cognitive outcomes —
> supporting the cognitive reserve hypothesis that education builds resilience against neurodegeneration.

Navigate to the **EDA Insights** page to explore these patterns interactively.
""")
