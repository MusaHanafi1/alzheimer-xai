"""
3_EDA_Insights.py — Interactive statistical visualizations.
"""

import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.stats import mannwhitneyu
import sys
import os

sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))
from src.data_loader import load_oasis
from src.preprocessing import clean_dataset
from src.feature_engineering import add_clinical_features

st.set_page_config(page_title="EDA Insights", page_icon="📈", layout="wide")
st.title("📈 EDA Insights")
st.markdown("Interactive statistical exploration of the OASIS dataset.")

DATA_PATH = os.path.join(os.path.dirname(__file__), '..', '..', 'data', 'raw', 'oasis_longitudinal.csv')

@st.cache_data
def load_and_prepare():
    try:
        df_raw = load_oasis(DATA_PATH)
        df_clean = clean_dataset(df_raw)
        df_eng = add_clinical_features(df_clean)
        df_eng['Group Label'] = df_eng['Diagnosis'].map({0: 'Nondemented', 1: 'Demented'})
        return df_eng
    except FileNotFoundError:
        return None

df = load_and_prepare()

if df is None:
    st.error("Dataset not found. Add `oasis_longitudinal.csv` to `data/raw/`.")
    st.stop()

PALETTE = {'Nondemented': '#2ca02c', 'Demented': '#d62728'}
CONTINUOUS = ['Age', 'EDUC', 'SES', 'MMSE', 'eTIV', 'nWBV', 'ASF']

tab1, tab2, tab3, tab4 = st.tabs(["Feature Distributions", "Group Comparisons", "Correlation Analysis", "Statistical Tests"])

# ── Tab 1: Distributions ──────────────────────────────────────────
with tab1:
    st.subheader("Univariate Feature Distributions")
    selected_feat = st.selectbox("Select feature to explore:", CONTINUOUS)

    col1, col2 = st.columns(2)

    with col1:
        fig, ax = plt.subplots(figsize=(7, 4))
        for label, color in PALETTE.items():
            diag_val = 0 if label == 'Nondemented' else 1
            subset = df[df['Diagnosis'] == diag_val][selected_feat].dropna()
            ax.hist(subset, bins=20, alpha=0.55, color=color,
                    label=f'{label} (n={len(subset)}, median={subset.median():.2f})',
                    edgecolor='white')
            ax.axvline(subset.median(), color=color, linestyle='--', linewidth=2)
        ax.set_xlabel(selected_feat, fontsize=11)
        ax.set_ylabel('Count')
        ax.set_title(f'{selected_feat} Distribution by Diagnosis', fontsize=12)
        ax.legend(fontsize=9)
        st.pyplot(fig)
        plt.close()

    with col2:
        fig, ax = plt.subplots(figsize=(7, 4))
        sns.boxplot(data=df, x='Group Label', y=selected_feat,
                    palette=PALETTE, width=0.5, ax=ax)
        sns.stripplot(data=df, x='Group Label', y=selected_feat,
                      palette=PALETTE, alpha=0.3, size=4, jitter=True, ax=ax)
        ax.set_xlabel('')
        ax.set_title(f'{selected_feat} — Boxplot by Group', fontsize=12)
        st.pyplot(fig)
        plt.close()

    # Mann-Whitney stats
    g0 = df[df['Diagnosis'] == 0][selected_feat].dropna()
    g1 = df[df['Diagnosis'] == 1][selected_feat].dropna()
    stat, pval = mannwhitneyu(g0, g1, alternative='two-sided')

    col_a, col_b, col_c, col_d = st.columns(4)
    col_a.metric("Nondemented Median", f"{g0.median():.3f}")
    col_b.metric("Demented Median", f"{g1.median():.3f}")
    col_c.metric("Mann-Whitney p-value", f"{pval:.5f}")
    col_d.metric("Significant?", "Yes ✅" if pval < 0.05 else "No ❌")

# ── Tab 2: Group Comparisons ──────────────────────────────────────
with tab2:
    st.subheader("All Features — Side-by-Side Group Comparison")

    fig, axes = plt.subplots(2, 4, figsize=(18, 9))
    axes = axes.flatten()
    for i, feat in enumerate(CONTINUOUS):
        ax = axes[i]
        sns.boxplot(data=df, x='Group Label', y=feat, palette=PALETTE, width=0.45, ax=ax)
        sns.stripplot(data=df, x='Group Label', y=feat, palette=PALETTE,
                      alpha=0.25, size=3.5, jitter=True, ax=ax)
        g0v = df[df['Diagnosis'] == 0][feat].dropna()
        g1v = df[df['Diagnosis'] == 1][feat].dropna()
        _, pv = mannwhitneyu(g0v, g1v, alternative='two-sided')
        sig = '***' if pv < 0.001 else ('**' if pv < 0.01 else ('*' if pv < 0.05 else 'ns'))
        ax.set_title(f'{feat}  [{sig}]', fontsize=11)
        ax.set_xlabel('')
    axes[-1].set_visible(False)
    plt.suptitle('Feature Distributions by Diagnosis (* p<.05, ** p<.01, *** p<.001)',
                 fontsize=13, fontweight='bold', y=1.01)
    plt.tight_layout()
    st.pyplot(fig)
    plt.close()

    st.caption("Statistical significance from Mann-Whitney U test (non-parametric, two-sided)")

# ── Tab 3: Correlation ────────────────────────────────────────────
with tab3:
    st.subheader("Correlation Heatmap")

    corr_cols = CONTINUOUS + ['Gender_Encoded', 'Diagnosis']
    available = [c for c in corr_cols if c in df.columns]
    corr_matrix = df[available].corr()

    fig, ax = plt.subplots(figsize=(10, 8))
    mask = np.triu(np.ones_like(corr_matrix, dtype=bool))
    sns.heatmap(corr_matrix, mask=mask, annot=True, fmt='.2f',
                cmap='RdBu_r', center=0, vmin=-1, vmax=1,
                linewidths=0.5, ax=ax, square=True)
    ax.set_title('Feature Correlation Heatmap (with Diagnosis)', fontsize=13, pad=12)
    plt.tight_layout()
    st.pyplot(fig)
    plt.close()

    st.markdown("---")
    st.subheader("Correlation with Diagnosis (sorted)")
    target_corr = corr_matrix['Diagnosis'].drop('Diagnosis').sort_values(key=abs, ascending=False)
    corr_df = pd.DataFrame({'Feature': target_corr.index, 'Correlation': target_corr.values.round(4)})
    corr_df['Direction'] = corr_df['Correlation'].apply(lambda x: 'Positive (↑ dementia risk)' if x > 0 else 'Negative (↓ dementia risk)')
    st.dataframe(corr_df, use_container_width=True)

# ── Tab 4: Statistical Tests ──────────────────────────────────────
with tab4:
    st.subheader("Statistical Hypothesis Testing — All Features")
    st.markdown("Mann-Whitney U test (non-parametric) + Cohen's d effect size for each continuous feature.")

    def cohens_d(a, b):
        n1, n2 = len(a), len(b)
        pooled = np.sqrt(((n1-1)*a.std()**2 + (n2-1)*b.std()**2) / (n1+n2-2))
        return abs((a.mean() - b.mean()) / pooled) if pooled > 0 else 0

    rows = []
    for feat in CONTINUOUS:
        g0 = df[df['Diagnosis'] == 0][feat].dropna()
        g1 = df[df['Diagnosis'] == 1][feat].dropna()
        _, pv = mannwhitneyu(g0, g1, alternative='two-sided')
        d = cohens_d(g0, g1)
        effect = 'Large' if d >= 0.8 else ('Medium' if d >= 0.5 else 'Small')
        rows.append({
            'Feature': feat,
            'Nondemented Median': round(g0.median(), 3),
            'Demented Median': round(g1.median(), 3),
            'p-value': round(pv, 5),
            'Significant (p<.05)': '✅' if pv < 0.05 else '❌',
            "Cohen's d": round(d, 3),
            'Effect Size': effect,
        })

    st.dataframe(pd.DataFrame(rows), use_container_width=True)

    st.markdown("""
    **Interpretation guide:**
    - **p < 0.05** → statistically significant difference between groups
    - **Cohen's d** → effect size: Small (~0.2), Medium (~0.5), Large (~0.8+)
    - MMSE and nWBV show the largest effects, confirming their clinical relevance
    """)
