"""
6_Patient_Predictor.py — Live patient risk prediction with real-time SHAP explanation.
"""

import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import shap
import sys
import os
import warnings
warnings.filterwarnings('ignore')

sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))
from src.data_loader import load_oasis
from src.preprocessing import clean_dataset, split_features_target, scale_features
from src.feature_engineering import add_clinical_features
from src.model_trainer import train_test_split_data, apply_smote, load_model
from src.explainer import get_shap_explainer, get_lime_explainer, explain_with_lime, plot_lime_explanation

st.set_page_config(page_title="Patient Predictor", page_icon="🩺", layout="wide")
st.title("🩺 Patient Risk Predictor")
st.markdown("""
Enter a patient's clinical measurements to get a real-time dementia risk prediction
with a full SHAP explanation of which features drove the result.

*This tool is for educational and research purposes only. It does not constitute medical advice.*
""")

DATA_PATH = os.path.join(os.path.dirname(__file__), '..', '..', 'data', 'raw', 'oasis_longitudinal.csv')
MODEL_PATH = os.path.join(os.path.dirname(__file__), '..', '..', 'models', 'best_model.pkl')

@st.cache_resource
def load_model_and_explainer():
    df_raw = load_oasis(DATA_PATH)
    df_clean = clean_dataset(df_raw)
    df_eng = add_clinical_features(df_clean)
    X, y = split_features_target(df_eng)
    X_train, X_test, y_train, y_test = train_test_split_data(X, y)
    X_train_sc, X_test_sc, scaler = scale_features(X_train, X_test)
    X_train_df = pd.DataFrame(X_train_sc, columns=X_train.columns)
    X_train_res, y_train_res = apply_smote(X_train_df, y_train.reset_index(drop=True))
    X_train_res = pd.DataFrame(X_train_res, columns=X_train.columns)
    model = load_model(MODEL_PATH)
    shap_explainer = get_shap_explainer(model, X_train_df)
    lime_explainer = get_lime_explainer(X_train_df)
    return model, shap_explainer, lime_explainer, scaler, X_train.columns.tolist()

if not os.path.exists(MODEL_PATH):
    st.warning("Model not found. Please run Notebook 05 to train and save the model first.")
    st.stop()

try:
    model, shap_explainer, lime_explainer, scaler, feature_names = load_model_and_explainer()
except Exception as e:
    st.error(f"Could not load model: {e}")
    st.stop()

st.markdown("---")

# ── Input Panel ────────────────────────────────────────────────────
st.subheader("Patient Clinical Profile")

col_left, col_right = st.columns([1, 2])

with col_left:
    st.markdown("**Demographics**")
    age    = st.slider("Age (years)", 60, 100, 75)
    gender = st.radio("Biological Sex", ["Male", "Female"], horizontal=True)
    gender_enc = 0 if gender == "Male" else 1
    educ   = st.slider("Years of Education", 6, 23, 14)
    ses    = st.slider("Socioeconomic Status (1=highest, 5=lowest)", 1, 5, 2)

    st.markdown("**Cognitive Assessment**")
    mmse   = st.slider("MMSE Score (0–30, higher=better)", 0, 30, 26)

    st.markdown("**MRI Measurements**")
    etiv   = st.number_input("eTIV (mm³)", min_value=900, max_value=2100, value=1500, step=10)
    nwbv   = st.number_input("nWBV (0.5–0.95)", min_value=0.50, max_value=0.95, value=0.74, step=0.001, format="%.3f")
    asf    = st.number_input("ASF", min_value=0.70, max_value=1.50, value=1.10, step=0.01, format="%.3f")

    run_btn = st.button("🔍 Predict & Explain", use_container_width=True, type="primary")

with col_right:
    if run_btn:
        # Build raw feature dict
        base_features = {
            'Age': age, 'EDUC': educ, 'SES': ses, 'MMSE': mmse,
            'eTIV': etiv, 'nWBV': nwbv, 'ASF': asf, 'Gender_Encoded': gender_enc
        }

        # Compute engineered features
        mmse_age_ratio  = mmse / age if age > 0 else 0
        brain_atrophy   = 1 - nwbv
        cognitive_res   = educ * mmse
        age_bracket     = 0 if age < 55 else (1 if age < 65 else (2 if age < 75 else 3))
        volume_adjusted = nwbv * etiv

        engineered = {
            'MMSE_Age_Ratio':      mmse_age_ratio,
            'Brain_Atrophy':       brain_atrophy,
            'Cognitive_Reserve':   cognitive_res,
            'Age_Bracket_Encoded': age_bracket,
            'Volume_Adjusted':     volume_adjusted,
        }

        all_features = {**base_features, **engineered}

        # Align to training feature order and scale
        patient_df = pd.DataFrame([{f: all_features.get(f, 0) for f in feature_names}])
        patient_scaled = scaler.transform(patient_df)
        patient_scaled_df = pd.DataFrame(patient_scaled, columns=feature_names)

        # Predict
        proba    = model.predict_proba(patient_scaled_df)[0]
        pred_cls = model.predict(patient_scaled_df)[0]

        # ── Prediction Result ──────────────────────────────────────
        risk_pct = proba[1] * 100
        if risk_pct >= 70:
            risk_color = "#d62728"
            risk_label = "HIGH RISK"
            risk_icon  = "🔴"
        elif risk_pct >= 40:
            risk_color = "#ff7f0e"
            risk_label = "MODERATE RISK"
            risk_icon  = "🟡"
        else:
            risk_color = "#2ca02c"
            risk_label = "LOW RISK"
            risk_icon  = "🟢"

        st.markdown(f"""
        <div style="background:{risk_color}15; border-left:5px solid {risk_color};
                    padding:1rem 1.2rem; border-radius:6px; margin-bottom:1rem;">
            <h2 style="color:{risk_color}; margin:0;">{risk_icon} {risk_label}</h2>
            <p style="font-size:1.1rem; margin:0.3rem 0 0;">
                Dementia Probability: <strong>{risk_pct:.1f}%</strong>
            </p>
        </div>
        """, unsafe_allow_html=True)

        r1, r2 = st.columns(2)
        r1.metric("P(Nondemented)", f"{proba[0]*100:.1f}%")
        r2.metric("P(Demented)",    f"{proba[1]*100:.1f}%")

        st.markdown("---")

        # ── SHAP Waterfall ─────────────────────────────────────────
        st.subheader("Why did the model predict this?")
        with st.spinner("Computing SHAP explanation..."):
            shap_exp = shap_explainer(patient_scaled_df)

        fig_wf, _ = plt.subplots(figsize=(9, 5))
        shap.plots.waterfall(shap_exp[0], max_display=10, show=False)
        plt.title("SHAP Waterfall — Feature Contributions to This Prediction", fontsize=11)
        plt.tight_layout()
        st.pyplot(fig_wf)
        plt.close()

        st.caption("""
        Each bar shows how a feature pushed the prediction above (red) or below (blue) the baseline.
        The final probability is the sum of all contributions starting from the model's base rate.
        """)

        st.markdown("---")

        # ── LIME Explanation ───────────────────────────────────────
        st.subheader("LIME Local Explanation")

        # LIME needs a reference dataset — use test data as background
        try:
            df_raw = load_oasis(DATA_PATH)
            df_clean = clean_dataset(df_raw)
            df_eng = add_clinical_features(df_clean)
            X_all, _ = split_features_target(df_eng)
            X_all_sc = scaler.transform(X_all)
            X_all_df = pd.DataFrame(X_all_sc, columns=feature_names)

            # Create a combined dataset and explain the last row (our patient)
            combined = pd.concat([X_all_df, patient_scaled_df], ignore_index=True)
            lime_weights = explain_with_lime(lime_explainer, model, combined, len(combined) - 1)

            fig_lime = plot_lime_explanation(lime_weights, patient_idx=0)
            st.pyplot(fig_lime)
            plt.close()
            st.caption("Green = pushes toward Demented, Red = pushes toward Nondemented.")

        except Exception as e:
            st.info("LIME explanation requires the full dataset to be available.")

        st.markdown("---")

        # ── Clinical Notes ─────────────────────────────────────────
        st.subheader("Clinical Context Notes")
        notes = []
        if mmse < 24:
            notes.append(f"⚠️ MMSE score of **{mmse}** is below the standard screening threshold of 24.")
        if mmse < 20:
            notes.append(f"🔴 MMSE score of **{mmse}** suggests possible moderate cognitive impairment.")
        if nwbv < 0.70:
            notes.append(f"⚠️ nWBV of **{nwbv:.3f}** is below average — possible brain atrophy signal.")
        if age > 80:
            notes.append(f"📅 Age **{age}** places this patient in the highest-risk demographic cohort.")
        if educ >= 16:
            notes.append(f"🎓 Education level of **{educ} years** may provide cognitive reserve.")

        if notes:
            for note in notes:
                st.markdown(note)
        else:
            st.success("All clinical indicators are within normal ranges.")

        st.markdown("""
        ---
        *Disclaimer: This prediction is generated by a machine learning model trained on a research dataset
        (OASIS). It is not a clinical diagnosis. All results should be interpreted by a qualified healthcare
        professional in the context of full clinical assessment.*
        """)
    else:
        st.info("Configure the patient profile on the left and click **Predict & Explain** to see the result.")

        st.markdown("""
        ### What You'll See
        - **Risk classification** with probability score
        - **SHAP waterfall** showing which features drove the prediction
        - **LIME explanation** in linear, interpretable terms
        - **Clinical notes** flagging any values outside normal ranges

        ---

        ### Feature Reference Ranges

        | Feature | Normal Range | Clinical Flag |
        |---------|-------------|---------------|
        | MMSE | 24–30 | < 24 suggests cognitive impairment |
        | nWBV | 0.72–0.88 | < 0.70 suggests atrophy |
        | Age | — | > 80 increases risk |
        | EDUC | — | Higher is protective |
        | SES | 1–5 | Lower SES associated with higher risk |
        """)
