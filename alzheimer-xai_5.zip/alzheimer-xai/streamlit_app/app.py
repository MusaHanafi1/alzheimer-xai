"""
app.py — Main entry point for the Alzheimer's XAI Streamlit Dashboard.
Run with: streamlit run streamlit_app/app.py
"""

import streamlit as st

st.set_page_config(
    page_title="Alzheimer's Classification & XAI",
    page_icon="🧠",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown("""
    <style>
    .main-header {
        font-size: 2.4rem;
        font-weight: 700;
        color: #1f3b73;
        line-height: 1.2;
    }
    .sub-header {
        font-size: 1.1rem;
        color: #555;
        margin-top: 0.3rem;
    }
    .metric-card {
        background: #f0f4ff;
        border-left: 4px solid #1f77b4;
        padding: 1rem 1.2rem;
        border-radius: 6px;
        margin: 0.4rem 0;
    }
    </style>
""", unsafe_allow_html=True)

st.markdown('<div class="main-header">🧠 Alzheimer\'s Disease Classification</div>', unsafe_allow_html=True)
st.markdown('<div class="sub-header">Explainable Machine Learning on the OASIS Longitudinal MRI Dataset</div>', unsafe_allow_html=True)

st.markdown("---")

col1, col2, col3, col4 = st.columns(4)
with col1:
    st.metric("Model", "XGBoost", "Tuned")
with col2:
    st.metric("Test Accuracy", "90.1%", "+8.1% vs baseline")
with col3:
    st.metric("AUC-ROC", "0.961", "Excellent")
with col4:
    st.metric("Recall (Demented)", "88.0%", "Priority metric")

st.markdown("---")
st.markdown("""
### Navigate the Dashboard

Use the sidebar to explore each section:

- **Project Overview** — Study context, dataset description, and methodology
- **Dataset Explorer** — Browse and filter the raw clinical data interactively
- **EDA Insights** — Statistical visualizations of clinical features and their relationship to diagnosis
- **Model Performance** — Confusion matrix, ROC curve, and full classification report
- **XAI Explanations** — SHAP global importance and LIME local explanations
- **Patient Predictor** — Enter a patient profile and get a real-time prediction with explanation

---
*Dataset: OASIS Longitudinal MRI Data | Washington University | [Kaggle](https://www.kaggle.com/datasets/jboysen/mri-and-alzheimers)*
""")
