"""
model_trainer.py
----------------
Handles model training, cross-validation, hyperparameter tuning,
and serialization for the Alzheimer's classification task.
"""

import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.model_selection import (
    StratifiedKFold, cross_val_score, GridSearchCV, train_test_split
)
from imblearn.over_sampling import SMOTE
from xgboost import XGBClassifier
import joblib
import os
import logging

logger = logging.getLogger(__name__)

RANDOM_STATE = 42


def get_all_models() -> dict:
    """
    Return a dictionary of all candidate classifiers with sensible defaults.
    """
    return {
        "Logistic Regression": LogisticRegression(
            random_state=RANDOM_STATE, max_iter=1000, class_weight="balanced"
        ),
        "Decision Tree": DecisionTreeClassifier(
            random_state=RANDOM_STATE, class_weight="balanced"
        ),
        "Random Forest": RandomForestClassifier(
            n_estimators=100, random_state=RANDOM_STATE, class_weight="balanced"
        ),
        "SVM": SVC(
            probability=True, random_state=RANDOM_STATE, class_weight="balanced"
        ),
        "XGBoost": XGBClassifier(
            random_state=RANDOM_STATE,
            eval_metric="logloss",
            use_label_encoder=False,
            scale_pos_weight=1,
        ),
    }


def train_test_split_data(X, y, test_size=0.2):
    """
    Stratified train/test split preserving class proportions.
    """
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=RANDOM_STATE, stratify=y
    )
    logger.info(f"Train: {X_train.shape}, Test: {X_test.shape}")
    logger.info(f"Train class dist: {pd.Series(y_train).value_counts().to_dict()}")
    logger.info(f"Test class dist:  {pd.Series(y_test).value_counts().to_dict()}")
    return X_train, X_test, y_train, y_test


def apply_smote(X_train, y_train):
    """
    Apply SMOTE oversampling to training data only.
    Never apply SMOTE to test data — this would leak information.

    Returns
    -------
    X_resampled, y_resampled
    """
    # Fill any residual NaNs before SMOTE — engineered features can introduce them
    if hasattr(X_train, "isnull") and X_train.isnull().any().any():
        nan_cols = X_train.columns[X_train.isnull().any()].tolist()
        logger.warning(f"Filling residual NaNs before SMOTE in columns: {nan_cols}")
        X_train = X_train.fillna(X_train.median())

    smote = SMOTE(random_state=RANDOM_STATE)
    X_res, y_res = smote.fit_resample(X_train, y_train)
    logger.info(f"After SMOTE — class distribution: {pd.Series(y_res).value_counts().to_dict()}")
    return X_res, y_res


def cross_validate_all_models(X, y, cv_folds=5) -> pd.DataFrame:
    """
    Run stratified k-fold cross-validation on all candidate models.
    Reports accuracy, F1, and AUC-ROC for each.

    Returns
    -------
    pd.DataFrame
        Summary DataFrame sorted by mean AUC-ROC.
    """
    models = get_all_models()
    cv = StratifiedKFold(n_splits=cv_folds, shuffle=True, random_state=RANDOM_STATE)
    results = []

    for name, model in models.items():
        acc  = cross_val_score(model, X, y, cv=cv, scoring="accuracy")
        f1   = cross_val_score(model, X, y, cv=cv, scoring="f1")
        auc  = cross_val_score(model, X, y, cv=cv, scoring="roc_auc")
        rec  = cross_val_score(model, X, y, cv=cv, scoring="recall")

        results.append({
            "Model": name,
            "Accuracy (mean)":  round(acc.mean(), 4),
            "Accuracy (std)":   round(acc.std(), 4),
            "F1 (mean)":        round(f1.mean(), 4),
            "Recall (mean)":    round(rec.mean(), 4),
            "AUC-ROC (mean)":   round(auc.mean(), 4),
            "AUC-ROC (std)":    round(auc.std(), 4),
        })
        logger.info(f"{name}: AUC={auc.mean():.4f} ± {auc.std():.4f}")

    return pd.DataFrame(results).sort_values("AUC-ROC (mean)", ascending=False)


def tune_xgboost(X_train, y_train, cv_folds=5) -> XGBClassifier:
    """
    GridSearchCV hyperparameter tuning for XGBoost.
    Returns the best estimator.
    """
    param_grid = {
        "n_estimators":    [100, 200, 300],
        "max_depth":       [3, 5, 7],
        "learning_rate":   [0.01, 0.05, 0.1],
        "subsample":       [0.8, 1.0],
        "colsample_bytree": [0.8, 1.0],
    }

    xgb = XGBClassifier(
        random_state=RANDOM_STATE,
        eval_metric="logloss",
        use_label_encoder=False,
    )

    grid_search = GridSearchCV(
        xgb,
        param_grid,
        cv=StratifiedKFold(n_splits=cv_folds, shuffle=True, random_state=RANDOM_STATE),
        scoring="roc_auc",
        n_jobs=-1,
        verbose=1,
    )

    grid_search.fit(X_train, y_train)
    logger.info(f"Best XGBoost params: {grid_search.best_params_}")
    logger.info(f"Best CV AUC-ROC: {grid_search.best_score_:.4f}")

    return grid_search.best_estimator_


def save_model(model, path: str) -> None:
    """Serialize a trained model to disk."""
    os.makedirs(os.path.dirname(path), exist_ok=True)
    joblib.dump(model, path)
    logger.info(f"Model saved to {path}")


def load_model(path: str):
    """Load a serialized model from disk."""
    if not os.path.exists(path):
        raise FileNotFoundError(f"No model found at {path}")
    return joblib.load(path)
