"""
feature_engineering.py
-----------------------
Creates derived clinical features to improve model signal.
All transformations are documented with clinical rationale.
"""

import pandas as pd
import numpy as np
from sklearn.preprocessing import PolynomialFeatures
import logging

logger = logging.getLogger(__name__)


def add_clinical_features(df: pd.DataFrame) -> pd.DataFrame:
    """
    Engineer clinically meaningful derived features from the OASIS dataset.

    New features created:
    - MMSE_Age_Ratio   : MMSE normalized by age — adjusts cognitive score for expected age-related decline
    - Brain_Atrophy    : 1 - nWBV, reframed as atrophy rather than volume (easier to interpret directionally)
    - Cognitive_Reserve: Interaction of EDUC * MMSE — captures protective effect of education on cognition
    - Age_Bracket      : Age grouped into clinical cohorts (young, middle, older, elderly)
    - Volume_Adjusted  : nWBV * eTIV — raw brain matter proxy before normalization

    Parameters
    ----------
    df : pd.DataFrame
        Cleaned DataFrame from preprocessing.py

    Returns
    -------
    pd.DataFrame
        DataFrame with additional engineered features.
    """
    df = df.copy()

    # MMSE adjusted for age — older patients may score lower without pathology
    if "MMSE" in df.columns and "Age" in df.columns:
        df["MMSE_Age_Ratio"] = df["MMSE"] / df["Age"].replace(0, np.nan)
        logger.info("Created: MMSE_Age_Ratio")

    # Reframe brain volume as atrophy (higher = more atrophy = worse)
    if "nWBV" in df.columns:
        df["Brain_Atrophy"] = 1 - df["nWBV"]
        logger.info("Created: Brain_Atrophy")

    # Education * MMSE — proxy for cognitive reserve
    if "EDUC" in df.columns and "MMSE" in df.columns:
        df["Cognitive_Reserve"] = df["EDUC"] * df["MMSE"]
        logger.info("Created: Cognitive_Reserve")

    # Age bracket groupings used in clinical literature
    if "Age" in df.columns:
        df["Age_Bracket"] = pd.cut(
            df["Age"],
            bins=[0, 55, 65, 75, 200],
            labels=["<55", "55-65", "65-75", "75+"]
        )
        # Encode ordinal age brackets
        bracket_map = {"<55": 0, "55-65": 1, "65-75": 2, "75+": 3}
        df["Age_Bracket_Encoded"] = df["Age_Bracket"].map(bracket_map)
        df.drop(columns=["Age_Bracket"], inplace=True)
        logger.info("Created: Age_Bracket_Encoded")

    # Raw brain volume proxy
    if "nWBV" in df.columns and "eTIV" in df.columns:
        df["Volume_Adjusted"] = df["nWBV"] * df["eTIV"]
        logger.info("Created: Volume_Adjusted")

    logger.info(f"Feature engineering complete. Shape: {df.shape}")
    return df


def get_engineered_feature_names() -> list:
    """Return list of all engineered feature column names."""
    return [
        "MMSE_Age_Ratio",
        "Brain_Atrophy",
        "Cognitive_Reserve",
        "Age_Bracket_Encoded",
        "Volume_Adjusted",
    ]


def get_full_feature_set() -> list:
    """Return the complete list of features including engineered ones."""
    base = ["Age", "EDUC", "SES", "MMSE", "eTIV", "nWBV", "ASF", "Gender_Encoded"]
    engineered = get_engineered_feature_names()
    return base + engineered
