"""
data_loader.py
--------------
Handles ingestion and initial validation of the OASIS longitudinal dataset.
Provides a clean, validated DataFrame ready for preprocessing.
"""

import pandas as pd
import numpy as np
import os
import logging

logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
logger = logging.getLogger(__name__)

# Expected columns in the raw OASIS dataset
EXPECTED_COLUMNS = [
    "Subject ID", "MRI ID", "Group", "Visit", "MR Delay",
    "M/F", "Hand", "Age", "EDUC", "SES", "MMSE",
    "CDR", "eTIV", "nWBV", "ASF"
]

# Clinical feature ranges for validation
VALID_RANGES = {
    "Age":  (18, 110),
    "EDUC": (0, 25),
    "SES":  (1, 5),
    "MMSE": (0, 30),
    "CDR":  (0.0, 3.0),
    "eTIV": (900, 2100),
    "nWBV": (0.5, 0.95),
    "ASF":  (0.7, 1.5),
}


def load_oasis(filepath: str) -> pd.DataFrame:
    """
    Load and validate the OASIS longitudinal CSV dataset.

    Parameters
    ----------
    filepath : str
        Path to oasis_longitudinal.csv

    Returns
    -------
    pd.DataFrame
        Raw validated DataFrame.

    Raises
    ------
    FileNotFoundError
        If the file does not exist at the provided path.
    ValueError
        If critical columns are missing from the file.
    """
    if not os.path.exists(filepath):
        raise FileNotFoundError(
            f"Dataset not found at: {filepath}\n"
            "Download oasis_longitudinal.csv from Kaggle and place it in data/raw/"
        )

    df = pd.read_csv(filepath)
    logger.info(f"Loaded dataset: {df.shape[0]} rows x {df.shape[1]} columns")

    # Check required columns
    missing_cols = [c for c in EXPECTED_COLUMNS if c not in df.columns]
    if missing_cols:
        raise ValueError(f"Missing expected columns: {missing_cols}")

    _log_data_quality(df)
    return df


def _log_data_quality(df: pd.DataFrame) -> None:
    """Print a quick data quality summary to the console."""
    logger.info("=== Data Quality Report ===")
    logger.info(f"Total records: {len(df)}")
    logger.info(f"Unique subjects: {df['Subject ID'].nunique()}")

    null_counts = df.isnull().sum()
    if null_counts.any():
        logger.warning("Missing values detected:")
        for col, cnt in null_counts[null_counts > 0].items():
            pct = (cnt / len(df)) * 100
            logger.warning(f"  {col}: {cnt} missing ({pct:.1f}%)")
    else:
        logger.info("No missing values found.")

    # Range validation
    for col, (low, high) in VALID_RANGES.items():
        if col in df.columns:
            out_of_range = df[col].dropna()
            violations = out_of_range[(out_of_range < low) | (out_of_range > high)]
            if len(violations) > 0:
                logger.warning(f"  {col}: {len(violations)} values outside [{low}, {high}]")


def get_feature_metadata() -> dict:
    """
    Return a dictionary describing each clinical feature.
    Useful for annotating charts and documentation.
    """
    return {
        "Age":  "Patient age in years",
        "EDUC": "Years of education",
        "SES":  "Socioeconomic status (1=highest, 5=lowest)",
        "MMSE": "Mini-Mental State Examination score (0–30, higher=better)",
        "CDR":  "Clinical Dementia Rating (0=none, 0.5=very mild, 1=mild, 2=moderate)",
        "eTIV": "Estimated total intracranial volume (mm³)",
        "nWBV": "Normalized whole brain volume (proportion)",
        "ASF":  "Atlas scaling factor (head size correction)",
        "M/F":  "Biological sex (M=Male, F=Female)",
        "EDUC": "Years of formal education",
        "Group": "Diagnostic group: Nondemented, Demented, or Converted",
    }
