"""
explainer.py
------------
SHAP and LIME explanation wrappers for the Alzheimer's XGBoost classifier.
Designed to work cleanly from both notebooks and the Streamlit app.
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import shap
from lime.lime_tabular import LimeTabularExplainer
import logging

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────
# SHAP Explanations
# ─────────────────────────────────────────────

def get_shap_explainer(model, X_train: pd.DataFrame) -> shap.TreeExplainer:
    """
    Create a SHAP TreeExplainer for tree-based models (XGBoost, RF).
    TreeExplainer is exact (not approximate) for these model families.
    """
    explainer = shap.TreeExplainer(model)
    logger.info("SHAP TreeExplainer initialized.")
    return explainer


def compute_shap_values(explainer: shap.TreeExplainer, X: pd.DataFrame) -> np.ndarray:
    """
    Compute SHAP values for a feature matrix X.

    Returns
    -------
    np.ndarray of shape (n_samples, n_features)
    """
    shap_values = explainer.shap_values(X)
    # For binary classifiers, shap_values may be a list [class0, class1]
    if isinstance(shap_values, list):
        return shap_values[1]
    return shap_values


def plot_shap_summary(shap_values: np.ndarray, X: pd.DataFrame,
                      save_path: str = None) -> plt.Figure:
    """
    Global SHAP summary beeswarm plot.
    Shows the distribution and direction of each feature's impact.
    """
    fig, ax = plt.subplots(figsize=(10, 6))
    shap.summary_plot(shap_values, X, show=False, plot_type="dot")
    plt.title("SHAP Summary — Feature Impact on Dementia Classification",
              fontsize=13, pad=12)
    plt.tight_layout()
    if save_path:
        fig.savefig(save_path, dpi=150, bbox_inches="tight")
    return fig


def plot_shap_bar(shap_values: np.ndarray, X: pd.DataFrame,
                  save_path: str = None) -> plt.Figure:
    """
    Global SHAP bar chart showing mean absolute SHAP values.
    Cleaner for executive/clinical audiences than the beeswarm.
    """
    mean_abs = np.abs(shap_values).mean(axis=0)
    importance_df = pd.DataFrame({
        "Feature": X.columns,
        "Mean |SHAP|": mean_abs
    }).sort_values("Mean |SHAP|", ascending=True)

    fig, ax = plt.subplots(figsize=(9, 5))
    bars = ax.barh(importance_df["Feature"], importance_df["Mean |SHAP|"],
                   color="#1f77b4", alpha=0.8, edgecolor="white")
    ax.set_xlabel("Mean |SHAP Value|", fontsize=12)
    ax.set_title("Feature Importance — Mean Absolute SHAP Values", fontsize=13, pad=12)
    for bar, val in zip(bars, importance_df["Mean |SHAP|"]):
        ax.text(val + 0.001, bar.get_y() + bar.get_height() / 2,
                f"{val:.4f}", va="center", fontsize=9)
    ax.grid(True, axis="x", alpha=0.3)
    plt.tight_layout()
    if save_path:
        fig.savefig(save_path, dpi=150, bbox_inches="tight")
    return fig


def plot_shap_waterfall(explainer, X: pd.DataFrame, idx: int,
                        save_path: str = None) -> plt.Figure:
    """
    Waterfall plot for a single patient prediction.
    Shows how each feature pushed the prediction above or below the baseline.

    Parameters
    ----------
    idx : int
        Row index of the patient in X.
    """
    shap_explanation = explainer(X.iloc[[idx]])

    fig, ax = plt.subplots(figsize=(10, 5))
    shap.plots.waterfall(shap_explanation[0], max_display=10, show=False)
    plt.title(f"SHAP Waterfall — Patient #{idx}", fontsize=12, pad=10)
    plt.tight_layout()
    if save_path:
        fig.savefig(save_path, dpi=150, bbox_inches="tight")
    return fig


def plot_shap_dependence(shap_values: np.ndarray, X: pd.DataFrame,
                         feature: str, interaction_feature: str = "MMSE",
                         save_path: str = None) -> plt.Figure:
    """
    SHAP dependence plot showing how one feature's SHAP value changes
    across its range, colored by an interaction feature.
    """
    fig, ax = plt.subplots(figsize=(8, 5))
    shap.dependence_plot(
        feature, shap_values, X,
        interaction_index=interaction_feature,
        ax=ax, show=False
    )
    ax.set_title(f"SHAP Dependence: {feature} (interaction: {interaction_feature})",
                 fontsize=12, pad=10)
    plt.tight_layout()
    if save_path:
        fig.savefig(save_path, dpi=150, bbox_inches="tight")
    return fig


# ─────────────────────────────────────────────
# LIME Explanations
# ─────────────────────────────────────────────

def get_lime_explainer(X_train: pd.DataFrame) -> LimeTabularExplainer:
    """
    Create a LIME tabular explainer fitted to training data statistics.
    """
    explainer = LimeTabularExplainer(
        training_data=X_train.values,
        feature_names=list(X_train.columns),
        class_names=["Nondemented", "Demented"],
        mode="classification",
        random_state=42,
        discretize_continuous=True,
    )
    logger.info("LIME TabularExplainer initialized.")
    return explainer


def explain_with_lime(lime_explainer: LimeTabularExplainer, model,
                      X: pd.DataFrame, idx: int,
                      num_features: int = 8) -> dict:
    """
    Generate a LIME explanation for a single patient prediction.

    Returns
    -------
    dict
        {feature_name: lime_weight} for top num_features features.
    """
    instance = X.iloc[idx].values
    predict_fn = lambda x: model.predict_proba(
        pd.DataFrame(x, columns=X.columns)
    )

    explanation = lime_explainer.explain_instance(
        instance,
        predict_fn,
        num_features=num_features,
        top_labels=1,
    )

    lime_weights = dict(explanation.as_list(label=1))
    return lime_weights


def plot_lime_explanation(lime_weights: dict, patient_idx: int,
                          save_path: str = None) -> plt.Figure:
    """
    Horizontal bar chart of LIME feature weights for one patient.
    Green bars push toward Demented, red bars push away.
    """
    features = list(lime_weights.keys())
    weights = list(lime_weights.values())
    colors = ["#2ca02c" if w > 0 else "#d62728" for w in weights]

    # Sort by absolute weight
    sorted_pairs = sorted(zip(features, weights, colors), key=lambda x: abs(x[1]))
    features, weights, colors = zip(*sorted_pairs)

    fig, ax = plt.subplots(figsize=(9, 5))
    ax.barh(features, weights, color=colors, alpha=0.8, edgecolor="white")
    ax.axvline(0, color="black", linewidth=0.8)
    ax.set_xlabel("LIME Weight (positive = toward Demented)", fontsize=11)
    ax.set_title(f"LIME Explanation — Patient #{patient_idx}", fontsize=13, pad=12)
    ax.grid(True, axis="x", alpha=0.3)
    plt.tight_layout()
    if save_path:
        fig.savefig(save_path, dpi=150, bbox_inches="tight")
    return fig
