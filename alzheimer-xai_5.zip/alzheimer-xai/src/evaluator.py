"""
evaluator.py
------------
Generates all evaluation artifacts: confusion matrix, classification report,
ROC curve, precision-recall curve, and threshold analysis.
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import seaborn as sns
from sklearn.metrics import (
    classification_report,
    confusion_matrix,
    roc_auc_score,
    roc_curve,
    precision_recall_curve,
    average_precision_score,
    f1_score,
    accuracy_score,
    recall_score,
    precision_score,
)
import logging
import os

logger = logging.getLogger(__name__)

FIGURE_DIR = "reports/figures"
os.makedirs(FIGURE_DIR, exist_ok=True)


def full_evaluation(model, X_test, y_test, model_name: str = "Model") -> dict:
    """
    Run complete evaluation on a trained model.

    Returns
    -------
    dict
        All computed metrics.
    """
    y_pred = model.predict(X_test)
    y_proba = model.predict_proba(X_test)[:, 1]

    metrics = {
        "accuracy":  round(accuracy_score(y_test, y_pred), 4),
        "recall":    round(recall_score(y_test, y_pred), 4),
        "precision": round(precision_score(y_test, y_pred), 4),
        "f1":        round(f1_score(y_test, y_pred), 4),
        "auc_roc":   round(roc_auc_score(y_test, y_proba), 4),
        "avg_precision": round(average_precision_score(y_test, y_proba), 4),
    }

    logger.info(f"\n=== {model_name} Evaluation ===")
    for k, v in metrics.items():
        logger.info(f"  {k}: {v}")
    logger.info("\n" + classification_report(y_test, y_pred,
                  target_names=["Nondemented", "Demented"]))

    return metrics


def plot_confusion_matrix(model, X_test, y_test, save_path: str = None) -> plt.Figure:
    """Plot a labeled, annotated confusion matrix."""
    y_pred = model.predict(X_test)
    cm = confusion_matrix(y_test, y_pred)

    fig, ax = plt.subplots(figsize=(7, 5))
    sns.heatmap(
        cm, annot=True, fmt="d", cmap="Blues",
        xticklabels=["Nondemented", "Demented"],
        yticklabels=["Nondemented", "Demented"],
        linewidths=0.5, ax=ax
    )
    ax.set_xlabel("Predicted Label", fontsize=12)
    ax.set_ylabel("True Label", fontsize=12)
    ax.set_title("Confusion Matrix — Alzheimer's Classification", fontsize=14, pad=15)

    # Annotate TN/FP/FN/TP
    labels = [["TN", "FP"], ["FN", "TP"]]
    for i in range(2):
        for j in range(2):
            ax.text(j + 0.5, i + 0.75, labels[i][j],
                    ha="center", va="center", fontsize=10,
                    color="gray", fontstyle="italic")

    plt.tight_layout()
    if save_path:
        fig.savefig(save_path, dpi=150, bbox_inches="tight")
    return fig


def plot_roc_curve(model, X_test, y_test, model_name: str = "XGBoost",
                   save_path: str = None) -> plt.Figure:
    """Plot ROC curve with AUC annotation."""
    y_proba = model.predict_proba(X_test)[:, 1]
    fpr, tpr, _ = roc_curve(y_test, y_proba)
    auc = roc_auc_score(y_test, y_proba)

    fig, ax = plt.subplots(figsize=(7, 6))
    ax.plot(fpr, tpr, color="#1f77b4", lw=2, label=f"{model_name} (AUC = {auc:.3f})")
    ax.plot([0, 1], [0, 1], "k--", lw=1, alpha=0.5, label="Random Classifier")
    ax.fill_between(fpr, tpr, alpha=0.08, color="#1f77b4")
    ax.set_xlabel("False Positive Rate", fontsize=12)
    ax.set_ylabel("True Positive Rate", fontsize=12)
    ax.set_title("ROC Curve — Alzheimer's Classification", fontsize=14, pad=15)
    ax.legend(loc="lower right", fontsize=11)
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    if save_path:
        fig.savefig(save_path, dpi=150, bbox_inches="tight")
    return fig


def plot_precision_recall(model, X_test, y_test, save_path: str = None) -> plt.Figure:
    """Plot Precision-Recall curve."""
    y_proba = model.predict_proba(X_test)[:, 1]
    precision, recall, _ = precision_recall_curve(y_test, y_proba)
    ap = average_precision_score(y_test, y_proba)

    fig, ax = plt.subplots(figsize=(7, 6))
    ax.plot(recall, precision, color="#d62728", lw=2, label=f"AP = {ap:.3f}")
    ax.fill_between(recall, precision, alpha=0.08, color="#d62728")
    ax.set_xlabel("Recall", fontsize=12)
    ax.set_ylabel("Precision", fontsize=12)
    ax.set_title("Precision-Recall Curve", fontsize=14, pad=15)
    ax.legend(fontsize=11)
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    if save_path:
        fig.savefig(save_path, dpi=150, bbox_inches="tight")
    return fig


def compare_models_chart(results_df: pd.DataFrame, save_path: str = None) -> plt.Figure:
    """
    Bar chart comparing all models on AUC-ROC, F1, and Recall.
    results_df should be output from model_trainer.cross_validate_all_models().
    """
    metrics = ["AUC-ROC (mean)", "F1 (mean)", "Recall (mean)"]
    colors = ["#1f77b4", "#2ca02c", "#ff7f0e"]

    fig, axes = plt.subplots(1, 3, figsize=(15, 5))
    fig.suptitle("Model Comparison — Cross-Validation Performance",
                 fontsize=14, fontweight="bold", y=1.02)

    for ax, metric, color in zip(axes, metrics, colors):
        bars = ax.barh(results_df["Model"], results_df[metric],
                       color=color, alpha=0.8, edgecolor="white")
        ax.set_xlim(0.5, 1.0)
        ax.set_title(metric, fontsize=12)
        ax.set_xlabel("Score")
        for bar, val in zip(bars, results_df[metric]):
            ax.text(val + 0.005, bar.get_y() + bar.get_height() / 2,
                    f"{val:.3f}", va="center", fontsize=10)
        ax.grid(True, axis="x", alpha=0.3)

    plt.tight_layout()
    if save_path:
        fig.savefig(save_path, dpi=150, bbox_inches="tight")
    return fig
