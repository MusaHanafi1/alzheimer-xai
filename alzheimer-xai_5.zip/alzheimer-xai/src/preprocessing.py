"""
preprocessing.py
----------------
Handles all data cleaning, imputation, encoding, and transformation steps
for the OASIS longitudinal Alzheimer's dataset.
"""

import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
import joblib
import logging
import os

logger = logging.getLogger(__name__)

# Columns that provide no analytical value
DROP_COLUMNS = ["Subject ID", "MRI ID", "Hand", "MR Delay"]

# Continuous features to scale
CONTINUOUS_FEATURES = ["Age", "EDUC", "SES", "MMSE", "eTIV", "nWBV", "ASF"]

# Final feature set used in modeling
MODEL_FEATURES = ["Age", "EDUC", "SES", "MMSE", "eTIV", "nWBV", "ASF", "Gender_Encoded"]

TARGET_COLUMN = "Diagnosis"


def clean_dataset(df: pd.DataFrame) -> pd.DataFrame:
    """
    Full cleaning pipeline: drop irrelevant columns, deduplicate,
    handle the 'Converted' group, impute missing values, encode categoricals,
    and create the binary target.

    Parameters
    ----------
    df : pd.DataFrame
        Raw DataFrame from load_oasis()

    Returns
    -------
    pd.DataFrame
        Cleaned DataFrame with all model-ready columns.
    """
    df = df.copy()

    # Step 1: Handle the 'Converted' group FIRST (before any drops)
    # 'Converted' patients were initially nondemented but progressed — treated as Demented
    df["Group"] = df["Group"].replace("Converted", "Demented")
    logger.info(f"Group distribution after Converted reassignment:\n{df['Group'].value_counts()}")

    # Step 2: Deduplicate — keep the most recent visit per subject
    # Must happen BEFORE dropping Subject ID, otherwise we have no key to deduplicate on
    if "Visit" in df.columns and "Subject ID" in df.columns:
        df.sort_values("Visit", ascending=False, inplace=True)
        df.drop_duplicates(subset=["Subject ID"], keep="first", inplace=True)
        df.drop(columns=["Visit"], inplace=True)
        logger.info(f"After deduplication (latest visit per subject): {df.shape}")

    # Step 3: Drop irrelevant identifiers (after deduplication so Subject ID is still available above)
    df.drop(columns=[c for c in DROP_COLUMNS if c in df.columns], inplace=True)
    logger.info(f"After dropping identifiers: {df.shape}")

    # Step 4: Impute missing values
    df = _impute_missing(df)

    # Step 5: Encode gender
    df["Gender_Encoded"] = df["M/F"].map({"M": 0, "F": 1})
    df.drop(columns=["M/F"], inplace=True)

    # Step 6: Create binary target from CDR
    # CDR = 0 → Nondemented (0), CDR > 0 → Demented (1)
    df[TARGET_COLUMN] = (df["CDR"] > 0).astype(int)
    df.drop(columns=["CDR", "Group"], inplace=True, errors="ignore")

    logger.info(f"Target distribution:\n{df[TARGET_COLUMN].value_counts()}")
    logger.info(f"Clean dataset shape: {df.shape}")

    return df


def _impute_missing(df: pd.DataFrame) -> pd.DataFrame:
    """
    Impute SES and MMSE using median values — the two columns with
    non-trivial missing rates in OASIS.
    """
    for col in ["SES", "MMSE"]:
        if col in df.columns:
            missing = df[col].isnull().sum()
            if missing > 0:
                median_val = df[col].median()
                df[col].fillna(median_val, inplace=True)
                logger.info(f"Imputed {missing} missing values in '{col}' with median={median_val:.2f}")
    return df


def split_features_target(df: pd.DataFrame):
    """
    Split cleaned (or engineered) DataFrame into feature matrix X and target vector y.
    Automatically picks up all columns except the target — so engineered features
    added by feature_engineering.py are included without needing to hardcode them.

    Returns
    -------
    X : pd.DataFrame
    y : pd.Series
    """
    if TARGET_COLUMN not in df.columns:
        raise ValueError(f"Target column '{TARGET_COLUMN}' not found in DataFrame.")
    feature_cols = [c for c in df.columns if c != TARGET_COLUMN]
    X = df[feature_cols]
    y = df[TARGET_COLUMN]
    return X, y


def scale_features(X_train: pd.DataFrame, X_test: pd.DataFrame, save_path: str = None):
    """
    Fit StandardScaler on training data only; transform both splits.
    Optionally serializes the scaler to disk.

    Returns
    -------
    X_train_scaled, X_test_scaled : np.ndarray
    scaler : StandardScaler
    """
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    if save_path:
        os.makedirs(os.path.dirname(save_path), exist_ok=True)
        joblib.dump(scaler, save_path)
        logger.info(f"Scaler saved to {save_path}")

    return X_train_scaled, X_test_scaled, scaler


def get_preprocessing_summary(df_raw: pd.DataFrame, df_clean: pd.DataFrame) -> dict:
    """
    Return a structured summary comparing raw vs. cleaned dataset.
    Useful for reporting in notebooks and the Streamlit app.
    """
    return {
        "raw_shape": df_raw.shape,
        "clean_shape": df_clean.shape,
        "rows_removed": df_raw.shape[0] - df_clean.shape[0],
        "missing_before": df_raw.isnull().sum().sum(),
        "missing_after": df_clean.isnull().sum().sum(),
        "target_distribution": df_clean[TARGET_COLUMN].value_counts().to_dict()
            if TARGET_COLUMN in df_clean.columns else {},
    }
