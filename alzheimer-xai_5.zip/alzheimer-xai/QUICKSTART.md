# Quickstart Guide

Get the full project running in under 5 minutes.

---

## Prerequisites

- Python 3.9 or higher
- Git

---

## 1. Clone the Repository

```bash
git clone https://github.com/MusaHanafi1/alzheimer-xai.git
cd alzheimer-xai
```

---

## 2. Install Dependencies

```bash
pip install -r requirements.txt
```

---

## 3. Train the Model

This runs the full pipeline — data cleaning, feature engineering, model training, evaluation, and saves all artifacts to `models/`.

```bash
# Full pipeline with hyperparameter tuning (~3-5 min)
python train.py

# Faster run using default hyperparameters (~30 sec)
python train.py --skip-tuning

# Train + immediately launch the Streamlit app
python train.py --launch
```

---

## 4. Launch the App

If you ran `train.py` without `--launch`, start the app manually:

```bash
streamlit run streamlit_app/app.py
```

Open **http://localhost:8501** in your browser.

---

## 5. Explore the Notebooks

The notebooks walk through the full analysis step by step:

```bash
jupyter notebook notebooks/
```

Run them in order: `01` → `02` → `03` → `04` → `05` → `06`

| Notebook | Content |
|----------|---------|
| 01 | Data understanding & profiling |
| 02 | Cleaning & preprocessing |
| 03 | EDA & statistical analysis |
| 04 | Feature engineering |
| 05 | Model training & evaluation |
| 06 | SHAP & LIME explainability |

---

## Dataset

A synthetic dataset (`data/raw/oasis_longitudinal.csv`) is included and mirrors
the statistical properties of the real OASIS longitudinal MRI dataset.

To use the real dataset instead:
1. Download `oasis_longitudinal.csv` from [Kaggle](https://www.kaggle.com/datasets/jboysen/mri-and-alzheimers)
2. Replace `data/raw/oasis_longitudinal.csv`
3. Add `data/raw/` to `.gitignore` to avoid committing patient data

---

## Project Structure

```
alzheimer-xai/
├── train.py                  ← Start here
├── data/raw/                 ← Dataset lives here
├── notebooks/                ← Full analysis (01–06)
├── src/                      ← Reusable Python modules
├── streamlit_app/            ← Interactive dashboard
├── models/                   ← Saved model artifacts (after training)
└── reports/figures/          ← Exported plots (after running notebooks)
```
