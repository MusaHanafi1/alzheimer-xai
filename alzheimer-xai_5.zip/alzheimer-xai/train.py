"""
train.py
--------
One-command pipeline: load data → clean → engineer features → train model → save.

Usage:
    python train.py                  # Full pipeline, no app launch
    python train.py --launch         # Full pipeline + launch Streamlit app
    python train.py --skip-tuning    # Skip GridSearchCV (faster, uses defaults)
    python train.py --launch --skip-tuning
"""

import argparse
import os
import sys
import json
import time
import subprocess
import warnings
warnings.filterwarnings("ignore")

import pandas as pd
import numpy as np
import joblib

# Ensure src/ is importable regardless of where train.py is invoked from
ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ROOT)

from src.data_loader import load_oasis
from src.preprocessing import clean_dataset, split_features_target, scale_features
from src.feature_engineering import add_clinical_features
from src.model_trainer import (
    train_test_split_data, apply_smote,
    cross_validate_all_models, tune_xgboost,
    get_all_models, save_model
)
from src.evaluator import full_evaluation

# ── Helpers ────────────────────────────────────────────────────────

def banner(text: str) -> None:
    width = 60
    print("\n" + "─" * width)
    print(f"  {text}")
    print("─" * width)

def ok(text: str)   -> None: print(f"  ✓  {text}")
def info(text: str) -> None: print(f"  →  {text}")
def warn(text: str) -> None: print(f"  ⚠  {text}")

# ── Main Pipeline ──────────────────────────────────────────────────

def run_pipeline(skip_tuning: bool = False) -> None:
    start = time.time()

    # ── Step 1: Load ──────────────────────────────────────────────
    banner("Step 1 / 6 — Loading Dataset")
    data_path = os.path.join(ROOT, "data", "raw", "oasis_longitudinal.csv")
    df_raw = load_oasis(data_path)
    ok(f"Loaded {df_raw.shape[0]} records, {df_raw.shape[1]} columns")
    ok(f"Unique subjects: {df_raw['Subject ID'].nunique()}")

    # ── Step 2: Clean ─────────────────────────────────────────────
    banner("Step 2 / 6 — Cleaning & Preprocessing")
    df_clean = clean_dataset(df_raw)
    ok(f"Clean shape: {df_clean.shape}")
    target_dist = df_clean["Diagnosis"].value_counts()
    ok(f"Target: {target_dist[0]} Nondemented  |  {target_dist[1]} Demented")

    # ── Step 3: Feature Engineering ───────────────────────────────
    banner("Step 3 / 6 — Feature Engineering")
    df_eng = add_clinical_features(df_clean)
    ok(f"Engineered shape: {df_eng.shape}")
    X, y = split_features_target(df_eng)
    ok(f"Features ({len(X.columns)}): {list(X.columns)}")

    # ── Step 4: Split + Scale + SMOTE ─────────────────────────────
    banner("Step 4 / 6 — Train/Test Split, Scaling & SMOTE")
    X_train, X_test, y_train, y_test = train_test_split_data(X, y, test_size=0.2)
    ok(f"Train: {X_train.shape}  |  Test: {X_test.shape}")

    models_dir = os.path.join(ROOT, "models")
    os.makedirs(models_dir, exist_ok=True)
    scaler_path = os.path.join(models_dir, "scaler.pkl")
    X_train_sc, X_test_sc, scaler = scale_features(X_train, X_test, save_path=scaler_path)
    ok(f"Scaler fitted and saved → {scaler_path}")

    X_train_df = pd.DataFrame(X_train_sc, columns=X_train.columns)
    X_test_df  = pd.DataFrame(X_test_sc,  columns=X_test.columns)

    X_train_res, y_train_res = apply_smote(X_train_df, y_train.reset_index(drop=True))
    X_train_res = pd.DataFrame(X_train_res, columns=X_train.columns)
    ok(f"After SMOTE — training shape: {X_train_res.shape}")

    # ── Step 5: Cross-Validate + Train ────────────────────────────
    banner("Step 5 / 6 — Model Training")

    if not skip_tuning:
        info("Running 5-fold cross-validation on all candidate models...")
        cv_results = cross_validate_all_models(X_train_df, y_train.reset_index(drop=True))
        print()
        print(cv_results[["Model", "AUC-ROC (mean)", "F1 (mean)", "Recall (mean)"]].to_string(index=False))
        print()
        info("Running GridSearchCV to tune XGBoost (this takes 2–5 min)...")
        best_model = tune_xgboost(X_train_res, y_train_res)
        ok(f"Best params: {best_model.get_xgb_params()}")
    else:
        warn("Skipping GridSearchCV — using default XGBoost hyperparameters")
        from xgboost import XGBClassifier
        best_model = XGBClassifier(
            n_estimators=200, max_depth=5, learning_rate=0.05,
            subsample=0.8, colsample_bytree=0.8,
            random_state=42, eval_metric="logloss", use_label_encoder=False
        )
        best_model.fit(X_train_res, y_train_res)
        ok("XGBoost fitted with default config")

    # ── Step 6: Evaluate + Save ───────────────────────────────────
    banner("Step 6 / 6 — Evaluation & Saving Artifacts")
    y_test_arr = y_test.reset_index(drop=True)
    metrics = full_evaluation(best_model, X_test_df, y_test_arr, "XGBoost")

    print()
    print("  ┌─────────────────────────────────┐")
    print(f"  │  Accuracy:          {metrics['accuracy']*100:>6.2f}%      │")
    print(f"  │  Recall (Demented): {metrics['recall']*100:>6.2f}%      │")
    print(f"  │  Precision:         {metrics['precision']*100:>6.2f}%      │")
    print(f"  │  F1 Score:          {metrics['f1']*100:>6.2f}%      │")
    print(f"  │  AUC-ROC:           {metrics['auc_roc']:>7.4f}       │")
    print("  └─────────────────────────────────┘")

    # Save model
    model_path = os.path.join(models_dir, "best_model.pkl")
    save_model(best_model, model_path)
    ok(f"Model saved → {model_path}")

    # Save feature names (used by Streamlit Patient Predictor)
    feature_names_path = os.path.join(models_dir, "feature_names.json")
    with open(feature_names_path, "w") as f:
        json.dump(list(X_train.columns), f, indent=2)
    ok(f"Feature names saved → {feature_names_path}")

    # Save metrics
    metrics_path = os.path.join(models_dir, "metrics.json")
    with open(metrics_path, "w") as f:
        json.dump(metrics, f, indent=2)
    ok(f"Metrics saved → {metrics_path}")

    elapsed = round(time.time() - start, 1)
    banner(f"Pipeline complete in {elapsed}s")
    print(f"  Artifacts in: {models_dir}/\n")


def launch_app() -> None:
    banner("Launching Streamlit App")
    app_path = os.path.join(ROOT, "streamlit_app", "app.py")
    info("Starting: streamlit run streamlit_app/app.py")
    info("Open http://localhost:8501 in your browser")
    info("Press Ctrl+C to stop\n")
    subprocess.run([sys.executable, "-m", "streamlit", "run", app_path], check=True)


# ── Entry Point ────────────────────────────────────────────────────

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Alzheimer's XAI — Full Training Pipeline",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python train.py                   # Train model, save artifacts
  python train.py --launch          # Train then launch Streamlit app
  python train.py --skip-tuning     # Fast run with default hyperparameters
        """
    )
    parser.add_argument(
        "--launch", action="store_true",
        help="Launch the Streamlit app after training completes"
    )
    parser.add_argument(
        "--skip-tuning", action="store_true",
        help="Skip GridSearchCV hyperparameter tuning (faster)"
    )
    args = parser.parse_args()

    print("\n🧠 Alzheimer's Disease Classification & Explainable ML")
    print("   Training Pipeline\n")

    try:
        run_pipeline(skip_tuning=args.skip_tuning)
        if args.launch:
            launch_app()
    except FileNotFoundError as e:
        print(f"\n  ✗  {e}")
        sys.exit(1)
    except KeyboardInterrupt:
        print("\n\n  Stopped.")
        sys.exit(0)
