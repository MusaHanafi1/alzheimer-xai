import unittest
import numpy as np
import pandas as pd
from sklearn.base import clone
from dementia_ml.data import FEATURES,DEMO,load_cohort,make_cohort
from dementia_ml.modeling import candidates,subject_split,select_threshold
from dementia_ml.evaluation import metrics,bootstrap_intervals

class IntegrityTests(unittest.TestCase):
    def setUp(self):self.cohort,self.X,self.y,self.meta=load_cohort()
    def test_subjects_are_disjoint_and_latest(self):
        train,test=subject_split(self.cohort,self.y)
        self.assertFalse(set(self.cohort.iloc[train]['Subject ID']) & set(self.cohort.iloc[test]['Subject ID']))
        raw=pd.read_csv(DEMO)
        self.assertTrue(self.cohort.set_index('Subject ID')['Visit'].eq(raw.groupby('Subject ID')['Visit'].max()).all())
    def test_only_allowlisted_predictors(self):
        self.assertEqual(list(self.X.columns),FEATURES)
        self.assertFalse(set(self.X.columns)&{'CDR','Group','Subject ID','MRI ID','Visit'})
    def test_missing_target_is_rejected(self):
        raw=pd.read_csv(DEMO);raw.loc[0,'CDR']=np.nan
        with self.assertRaises(ValueError):make_cohort(raw)
    def test_conflicting_visit_rejected(self):
        raw=pd.read_csv(DEMO);duplicate=raw.iloc[[0]].copy();duplicate['MMSE']=1
        with self.assertRaises(ValueError):make_cohort(pd.concat([raw,duplicate]))
    def test_synthetic_cannot_be_declared_real(self):
        with self.assertRaises(ValueError):load_cohort(DEMO,'real','OASIS')
    def test_imputer_sees_training_only(self):
        p,_=candidates(use_xgboost=False)['logistic_regression']
        x=pd.DataFrame({'feature':[1.,3.,np.nan,5.]});p.fit(x,[0,1,0,1])
        before=p['impute'].statistics_.copy();p.predict_proba(pd.DataFrame({'feature':[10000.,np.nan]}))
        np.testing.assert_array_equal(p['impute'].statistics_,before)
        self.assertEqual(before[0],3.)
        self.assertFalse(hasattr(clone(p)['impute'],'statistics_'))
    def test_threshold_rule_and_metrics(self):
        chosen,_=select_threshold([0,0,1,1],[.1,.8,.4,.9],.8)
        self.assertGreaterEqual(chosen['recall'],.8)
        m=metrics([0,0,1,1],[.1,.8,.4,.9],chosen['threshold'])
        self.assertAlmostEqual(m['recall'],chosen['recall'])
        self.assertEqual(sum(sum(r) for r in m['confusion_matrix']),4)
    def test_bootstrap_reproducible(self):
        a=bootstrap_intervals([0,0,1,1],[.1,.6,.4,.9],repeats=100)
        b=bootstrap_intervals([0,0,1,1],[.1,.6,.4,.9],repeats=100)
        self.assertEqual(a,b)
    def test_repeat_split_is_deterministic(self):
        a,b=subject_split(self.cohort,self.y);c,d=subject_split(self.cohort,self.y)
        np.testing.assert_array_equal(a,c);np.testing.assert_array_equal(b,d)

if __name__=='__main__':unittest.main()
