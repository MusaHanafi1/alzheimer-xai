"""Exercise Streamlit page modes and a submitted prediction without a browser."""
import unittest
from dementia_ml.data import ROOT

@unittest.skipUnless((ROOT/'reports/demo/model.joblib').exists(),'Run python train.py first')
class AppTests(unittest.TestCase):
    def test_pages_and_prediction(self):
        from streamlit.testing.v1 import AppTest
        app=AppTest.from_file(str(ROOT/'streamlit_app/app.py'),default_timeout=30).run()
        self.assertEqual(len(app.exception),0)
        for page in ['Model evaluation','Interpretability','Methods & limitations','Example prediction']:
            app.sidebar.radio[0].set_value(page).run()
            self.assertEqual(len(app.exception),0,page)
        app.button[0].click().run()
        self.assertEqual(len(app.exception),0)
        self.assertTrue(any('probability' in x.label.lower() for x in app.metric))
