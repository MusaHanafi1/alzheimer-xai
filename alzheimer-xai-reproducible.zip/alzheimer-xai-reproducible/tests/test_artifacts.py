"""Integration checks for an existing generated demo run."""
import unittest,json
from pathlib import Path
import numpy as np
import pandas as pd
import joblib
from dementia_ml.data import ROOT,load_cohort
from dementia_ml.modeling import subject_split
from dementia_ml.evaluation import metrics

@unittest.skipUnless((ROOT/'reports/demo/model.joblib').exists(),'Run python train.py first')
class ArtifactTests(unittest.TestCase):
    def test_model_reproduces_saved_probabilities_and_metrics(self):
        c,X,y,meta=load_cohort();tr,te=subject_split(c,y)
        bundle=joblib.load(ROOT/'reports/demo/model.joblib')
        p=bundle['model'].predict_proba(X.iloc[te])[:,1]
        saved=pd.read_csv(ROOT/'reports/demo/synthetic_holdout_predictions.csv')
        np.testing.assert_allclose(p,saved.probability,rtol=1e-12)
        r=json.loads((ROOT/'reports/demo/metrics.json').read_text())
        actual=metrics(y.iloc[te],p,bundle['threshold'])
        for k in ['roc_auc','accuracy','recall','precision','f1','brier']:
            self.assertAlmostEqual(actual[k],r['final_calibrated_model'][k])
    def test_shap_local_additivity(self):
        p=ROOT/'reports/demo/shap_example.json'
        if not p.exists():self.skipTest('SHAP example not generated')
        d=json.loads(p.read_text())
        self.assertAlmostEqual(d['base_probability']+sum(d['contributions'].values()),d['positive_probability'],places=5)
    def test_hashed_split_manifest_disjoint(self):
        d=json.loads((ROOT/'reports/demo/split_manifest.json').read_text())
        self.assertEqual(len(d['development']),120);self.assertEqual(len(d['test']),30)
        self.assertFalse(set(d['development']) & set(d['test']))
