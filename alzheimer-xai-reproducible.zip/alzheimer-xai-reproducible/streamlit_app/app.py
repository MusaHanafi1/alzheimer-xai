"""Interactive viewer for locally generated benchmark artifacts."""
from pathlib import Path
import json,sys
import numpy as np
import pandas as pd
import joblib
import streamlit as st
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from dementia_ml.data import FEATURES,load_cohort
st.set_page_config(page_title='Dementia ML | Musa Hanafi',page_icon='🧠',layout='wide')
st.title('Explainable dementia classification')
st.caption('Musa Hanafi · Reproducible ML evaluation')
run=ROOT/'reports/demo'
if not (run/'metrics.json').exists() or not (run/'model.joblib').exists():
    st.info('Generate the demo artifacts first: python train.py --shap');st.stop()
report=json.loads((run/'metrics.json').read_text());m=report['final_calibrated_model']
st.warning('SYNTHETIC DATA DEMONSTRATION. Classifies same-visit CDR status in a toy dataset. Not a diagnosis or future-risk estimate.')
mode=st.sidebar.radio('Explore',['Run overview','Model evaluation','Example prediction','Interpretability','Methods & limitations'])
if mode=='Run overview':
    cols=st.columns(4)
    for col,label,value in zip(cols,['Subjects','Holdout subjects','ROC-AUC','Recall'],[report['provenance']['dataset']['subjects'],m['n'],f'{m["roc_auc"]:.3f}',f'{m["recall"]:.3f}']):col.metric(label,value)
    st.write('Selected model:',report['selected_model']);st.write('Decision threshold:',m['threshold'])
    st.write('One latest observed visit per subject, preprocessing inside CV, training-only model and threshold selection, sigmoid calibration, and a separate final holdout.')
    st.image(str(run/'benchmark.png'))
    st.download_button('Download run metrics',data=(run/'metrics.json').read_text(),file_name='synthetic_benchmark_metrics.json',mime='application/json')
elif mode=='Model evaluation':
    st.subheader('Development model selection');st.dataframe(pd.DataFrame(report['selection_cv']),hide_index=True)
    st.caption('Selection CV scores are not unbiased final performance estimates.')
    st.subheader('Final calibrated holdout evaluation');st.json(m)
    st.subheader('95% stratified bootstrap intervals');st.dataframe(pd.DataFrame(report['confidence_intervals']).T)
    st.subheader('Descriptive subgroup errors');st.dataframe(pd.DataFrame(report['subgroups'])[['feature','group','n','positive_n','recall','precision']],hide_index=True)
    st.caption('These small subgroups do not establish fairness.')
elif mode=='Example prediction':
    st.subheader('Explore a synthetic profile')
    st.write('This demonstration uses the full saved preprocessing and calibration pipeline. The decision threshold is fixed from development data.')
    cohort,X,y,meta=load_cohort();row=X.iloc[0]
    with st.form('profile'):
        cols=st.columns(2);values={}
        bounds={'Age':(18.,110.),'EDUC':(0.,30.),'SES':(1.,5.),'MMSE':(0.,30.),'eTIV':(500.,2500.),'nWBV':(.4,1.),'ASF':(.4,2.)}
        for i,key in enumerate(FEATURES):
            if key=='Gender_Encoded':
                sex=cols[i%2].selectbox('Dataset sex category',['M','F']);values[key]=float(sex=='F')
            else:
                low,high=bounds[key]
                values[key]=cols[i%2].number_input(key,min_value=low,max_value=high,value=float(np.clip(row[key] if pd.notna(row[key]) else X[key].median(),low,high)),format='%.3f')
        submitted=st.form_submit_button('Evaluate example')
    if submitted:
        # This is a locally produced artifact. Never load joblib files supplied by strangers.
        bundle=joblib.load(run/'model.joblib')
        example=pd.DataFrame([values],columns=bundle['features'])
        probability=float(bundle['model'].predict_proba(example)[0,1])
        st.metric('Synthetic-model probability of CDR > 0',f'{probability:.3f}')
        st.write('Thresholded class:', 'CDR > 0' if probability>=bundle['threshold'] else 'CDR = 0')
        st.caption('A model output from synthetic training data is not a medical assessment.')
elif mode=='Interpretability':
    st.write('Permutation importance on development data. Correlated features can share or mask importance; this is not causal evidence.')
    importance=pd.read_csv(run/'feature_importance.csv');st.bar_chart(importance.set_index('feature')['mean_decrease_auc'])
    if (run/'shap_example.json').exists():
        explanation=json.loads((run/'shap_example.json').read_text());st.subheader('One synthetic SHAP example')
        st.caption(explanation['explained_output']);st.write('Explained base model:',explanation['explained_model'])
        st.bar_chart(pd.Series(explanation['contributions'],name='Contribution to uncalibrated positive probability'))
        st.json({k:v for k,v in explanation.items() if k!='contributions'})
    else:st.info('Run python train.py --shap to generate the local explanation.')
else:
    st.json(report['provenance'])
    for limitation in report['limitations']:st.write('• '+limitation)
    st.write('See docs/MODEL_CARD.md and docs/AUDIT.md for the evaluation choices and original-project corrections.')
