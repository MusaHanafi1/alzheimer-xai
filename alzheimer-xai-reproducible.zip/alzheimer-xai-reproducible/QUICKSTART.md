# Quickstart

Python 3.12 recommended. Run from the extracted project directory.

```bash
python -m venv .venv
```

Activate it on Windows:

```powershell
.venv\Scripts\Activate.ps1
```

Or on macOS/Linux:

```bash
source .venv/bin/activate
```

Then:

```bash
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
python train.py --shap
python -m streamlit run streamlit_app/app.py
```

Open `reports/demo/report.html` for the self-contained report. The included report is from the bundled **synthetic** dataset. It can be read without installing Python.

For a faster smoke run: `python train.py --bootstrap 200 --no-xgboost --output reports/smoke`. Model candidates will differ; do not compare its selected result as though it were the full benchmark.

A separate authorized real-data run:

```bash
python train.py --data data/private/oasis_longitudinal.csv --data-kind real --source "Provider, dataset version, access date, and citation" --output reports/real/run-01
```

No real data is downloaded or published by this project. The Streamlit app intentionally displays the synthetic demo run.
