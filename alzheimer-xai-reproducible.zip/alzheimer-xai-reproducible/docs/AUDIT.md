# Original-project audit and migration

## Source inspected

Original public repository: https://github.com/MusaHanafi1/alzheimer-xai

Inspected source commit: `2c58f2afb2886412413795bfde3b49c12b8ab774`.
The repository contained `alzheimer-xai_5.zip`. This revision was developed from inspection of the archive and retains the bundled CSV as explicitly synthetic demo data. No externally supplied pickle model was executed. The original archive is unchanged remotely.

## Findings and corrections

| Original issue | Revision |
|---|---|
| Top-level repository contains only a ZIP | This package is structured as directly browsable source files, ready for repository upload |
| README says 373 subjects / 150 visits | Original OASIS-2 describes 150 subjects / 373 imaging sessions; the bundled synthetic CSV actually contains 150 subjects / 317 rows |
| Synthetic and original-data descriptions intermingled | Synthetic provenance, SHA-256, source, cohort counts, run label, and limitations are saved with every run |
| README reports 90.1% accuracy / 0.96 ROC-AUC, while saved metrics say 0.8333 / 0.8889 | Neither old value is treated as reproduced. New results are generated from one saved run and its JSON; no numeric improvement over the old claims is asserted |
| Full-data median imputation before split | Imputation and scaling are in the estimator Pipeline; CV clones and fits them on each training fold |
| Scaling done before CV | Scaling now lives inside the cloned pipeline |
| SMOTE before GridSearchCV | No oversampling in the revised benchmark. Logistic regression and random forest use class weighting; XGBoost uses its specified objective without sampling |
| Contemporaneous CDR labeling framed as Alzheimer's progression | Task explicitly defined as classification of same-visit CDR > 0; not pathology confirmation, diagnosis, or future progression |
| Flexible selection of all non-target columns | Explicit eight-feature allowlist excludes labels and identifiers |
| Row overlap risks in longitudinal data | One latest observed visit per subject; subject IDs retained for split assertions but never passed to the model |
| Sparse uncertainty and error analysis | Stratified bootstrap intervals, PR/ROC, calibration, confusion matrix, and small-sample subgroup summaries |
| Documentation says deployed without verified deployment | Streamlit source and tested local interaction are supplied; no public Streamlit deployment claim |

## Important residual limits

- Synthetic generation code was not present in the inspected archive. Distributional fidelity to original OASIS is not independently verified.
- Selecting one latest visit changes the study design. It classifies status at that observation, not entry-time future risk.
- CDR and MMSE measure related constructs; even leakage-controlled evaluation may be a limited scientific task.
- Grid-search CV scores are for model selection. Hyperparameter selection is not nested inside the later development OOF threshold procedure, so training OOF diagnostics may be optimistic. The final holdout remains excluded from these choices.
- A seeded holdout becomes familiar after publication. Future iterative improvements should use newly declared evaluation protocols, nested CV, or independently acquired data rather than repeatedly optimizing to this small test set.
- Results are synthetic software demonstrations. No clinical performance is inferred.
