# Publish the improved source without Rube

The delivered package is ready to add to the existing `MusaHanafi1/alzheimer-xai` repository. No remote GitHub changes were made during this revision.

## With GitHub Desktop

1. Sign in to GitHub Desktop with the account that owns `MusaHanafi1/alzheimer-xai`.
2. Clone that existing repository to your computer.
3. Extract `alzheimer-xai-reproducible.zip` outside the clone.
4. Copy the **contents** of the extracted `alzheimer-xai-reproducible` folder into the clone root. README.md and train.py should appear at the top level, not inside another nested folder.
5. Inspect the changes in GitHub Desktop. Keep the original ZIP as an historical artifact if desired; the improved source and README are what visitors should see first.
6. Commit with a message such as `Add reproducible synthetic dementia benchmark`, then push.
7. Inspect the Actions tab to confirm CI passes. No model accuracy claim should be made from the green CI badge; it verifies code and artifacts on synthetic data.

The local model.joblib is ignored by Git. Running training recreates it. The synthetic CSV and generated report are intentionally included; private real-data directories and their reports are ignored.

## Optional Streamlit hosting

After the code is pushed, a hosted app needs the generated demo model artifact. The simplest local path is already tested: run training, then `python -m streamlit run streamlit_app/app.py`. Public Streamlit hosting is not configured or verified in this delivery. It should be set up deliberately with a trusted generated artifact or an appropriate build step.

## Portfolio links

The revised portfolio links to the existing GitHub repository and a hosted synthetic run report. Until you upload the new source, the GitHub link still opens the original ZIP-only repository. The hosted report describes the completed local revision accurately and does not imply the updated code has already been pushed.
