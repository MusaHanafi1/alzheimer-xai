# Interview walkthrough

## A 60-second introduction

I rebuilt an existing explainable dementia classification prototype around reproducible evaluation. The available dataset is synthetic, so I present the scores as a software demonstration, not clinical evidence. The work compares baseline and ML candidates, fits preprocessing inside cross-validation, separates development from holdout subjects, and reports calibration, uncertainty, and subgroup errors. The strongest part of the project is its audit trail: the data hash, model-selection rule, and generated report all agree.

## Questions to prepare

**Why keep one visit per subject?** It prevents the same participant appearing across folds while keeping the task straightforward. I use the latest visit and explicitly describe same-visit status classification. Modeling progression would require a different temporal design.

**Why did you remove SMOTE?** Class weighting and a no-resampling baseline make the small benchmark simpler. The original code oversampled before tuning folds, which could contaminate validation. If I reintroduce sampling, it will be inside an imbalanced-learn pipeline fitted separately within each fold.

**Why report more than ROC-AUC?** Ranking, probability reliability, and decision errors are different questions. Average precision, Brier score, calibration plots, recall, and confusion counts each expose a different aspect.

**Why can a recall target of 0.8 miss that on test data?** The threshold is estimated from development data. New samples vary; the target is not a guarantee. I report actual held-out recall and uncertainty without retuning on the test results.

**What does SHAP explain?** The optional example explains the selected uncalibrated estimator's positive probability. I do not imply that its contributions sum to the final calibrated prediction.

**What is the largest limitation?** Synthetic data cannot establish clinical usefulness. MMSE/CDR construct overlap and a small holdout further restrict interpretation. Real-data validation is a separate scientific next step.

**What did AI assistance contribute?** AI assisted with code revision, documentation and analysis. I should be able to explain, verify and reproduce every result I present. I will not claim unaided authorship or research novelty based on this implementation.

## Demonstration order

1. State the synthetic-data scope.
2. Show the generated report and exact cohort counts.
3. Explain model selection and the final calibrated holdout result.
4. Demonstrate threshold tradeoffs without replacing the saved evaluation.
5. Show preprocessing leakage tests and the GitHub source structure.
6. End with a real-data validation plan and the limitations.
