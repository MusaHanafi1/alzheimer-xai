# Model card: CDR-status classification demonstration

**Owner:** Musa Hanafi. **Revision:** 2.0.0. **Status:** synthetic-data software benchmark.

## Task and intended use

Classify whether contemporaneous Clinical Dementia Rating is greater than zero, using tabular demographic, cognitive, and imaging-derived predictors. Intended for learning, software verification, and portfolio discussion. It is not a clinical diagnostic, prognosis, or patient-management system.

## Data

The bundled CSV is labeled synthetic in the original project's README and quickstart. It contains 317 visit rows for 150 unique subjects. The original simulation code is unavailable. No claim is made that it faithfully reproduces the OASIS population. The benchmark keeps the latest observed visit per subject, leaving one record for each of 150 subjects. Input file SHA-256 and missingness are recorded by the training command.

For real-data work, obtain data under the provider's terms and supply a source citation. The command refuses to label the bundled CSV as real. Real-data runs default to the user's specified local directory; use `--output reports/real/<run>` (gitignored). Real-data per-subject predictions are not exported by default. Hashed split IDs are local audit metadata and are not anonymization guarantees. Do not publish source participant files without appropriate authorization.

## Predictors and target

Predictors: Age, EDUC, SES, MMSE, eTIV, nWBV, ASF, and dataset sex category encoded M=0/F=1. CDR > 0 defines the positive class. CDR, Group, visit IDs, subject IDs, MRI IDs, and administrative variables are excluded from model inputs. Model interpretation must account for construct overlap between MMSE and CDR. Predictions outside the dataset feature domain are unsupported.

## Training and evaluation

1. Validate required columns and numeric labels; reject missing outcomes and conflicting subject/visit records.
2. Select the latest visit per subject deterministically.
3. Split subjects 80/20, stratified on the binary outcome, seed 42.
4. Compare prevalence baseline, logistic regression, random forest, and XGBoost using five-fold development CV. Fit imputation and scaling inside each fold. Choose non-dummy model by selection CV ROC-AUC.
5. Prespecified sigmoid calibration wraps the complete selected pipeline with three-fold training cross-fitting.
6. Generate development OOF probabilities with five-fold CV. Choose threshold maximizing precision among candidate thresholds meeting recall >= 0.80; resolve ties by higher threshold. This is a development preference, not a medical operating requirement or guarantee.
7. Fit the calibrated model on development data, then evaluate on the holdout. Do not revise model or threshold from holdout scores.

Threshold OOF predictions reuse parameters selected from development CV. This is documented rather than described as unbiased nested evaluation. Candidate holdout comparisons are descriptive; the selected model is fixed by development CV before observing them.

## Results

See `reports/demo/metrics.json` for exact values, `report.html` for interpretation, and `benchmark.png` for figures. The raw selected model's performance differs from the calibrated final model. The thresholded final result also differs from the threshold-0.5 reference. All must be labeled precisely.

Bootstrap: 1,000 stratified test-subject resamples with fixed model and fixed class counts. Intervals describe conditional test-sample uncertainty; they do not include model retraining or population-prevalence uncertainty.

## Interpretability and errors

Training permutation importance measures reliance, not causal effect. The optional SHAP example explains uncalibrated positive-class probabilities for the selected raw estimator, not the calibration ensemble. Subgroup error analysis by sex and age is descriptive with sample counts. Small groups cannot establish fairness or reliable between-group differences.

## Reproducibility and dependencies

Python 3.12 and pinned requirements. The run records core dependency versions, seed, input hash, and hashed memberships. Re-run with `python train.py --shap`. Saved joblib artifacts must only be loaded from trusted runs. No source dataset beyond the synthetic demo is fetched automatically.

## Next scientific extension

A separately declared evaluation on authorized real data, with correct citations, participant separation, prospectively specified feature availability, and an external validation plan. An MMSE ablation could investigate construct overlap but is not claimed as completed here.
